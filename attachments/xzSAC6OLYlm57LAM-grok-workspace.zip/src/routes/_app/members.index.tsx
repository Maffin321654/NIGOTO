import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronRight } from "lucide-react";
import { PageHeader } from "@/components/page-header";
import { EmptyState } from "@/components/empty-state";
import { ROLE_LABEL, STATUS_LABEL } from "@/lib/constants";
import { listMembers } from "@/lib/server/fns";
import { useRpc } from "@/lib/use-rpc";

export const Route = createFileRoute("/_app/members/")({ component: Members });

function Members() {
  const { data, loading, err } = useRpc(() => listMembers());
  if (loading) return <p className="text-muted">Đang tải…</p>;
  if (err) return <p className="text-accent">{err}</p>;
  const rows = data ?? [];
  return (
    <div>
      <PageHeader kicker="Nhân sự" title="Thành viên" desc="Danh sách toàn CLB. Bấm một người để xem hồ sơ chi tiết." />
      {rows.length === 0 ? <EmptyState title="Chưa có thành viên" /> : (
        <div className="card-paper overflow-hidden">
          <div className="hidden grid-cols-12 gap-2 border-b border-line px-5 py-3 text-xs uppercase tracking-wider text-muted md:grid">
            <span className="col-span-4">Họ tên</span>
            <span className="col-span-2">MSSV</span>
            <span className="col-span-3">Ban</span>
            <span className="col-span-2">Vai trò</span>
            <span className="col-span-1" />
          </div>
          {rows.map((m) => (
            <Link
              key={m.user_id}
              to="/members/$id"
              params={{ id: m.user_id }}
              className="grid grid-cols-[1fr_auto] gap-1 border-b border-line px-5 py-4 last:border-0 hover:bg-paper-2 md:grid-cols-12 md:items-center"
            >
              <span className="font-medium break-words md:col-span-4">{m.full_name}</span>
              <span className="font-mono text-sm text-muted md:col-span-2">{m.student_id}</span>
              <span className="text-sm text-muted md:col-span-3">{m.depts || "—"}</span>
              <span className="text-sm md:col-span-2">{ROLE_LABEL[m.role] ?? m.role} · {STATUS_LABEL[m.status] ?? m.status}</span>
              <span className="hidden justify-end text-muted md:col-span-1 md:flex"><ChevronRight className="size-4" /></span>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

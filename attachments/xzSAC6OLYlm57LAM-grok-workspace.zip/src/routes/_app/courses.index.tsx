import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import { Field } from "@/components/field";
import { EmptyState } from "@/components/empty-state";
import { Button } from "@/components/ui/button";
import { Input, Textarea } from "@/components/ui/input";
import { LIMITS } from "@/lib/constants";
import { listCourses, saveCourse } from "@/lib/server/fns";
import { errorMessage } from "@/lib/utils";
import { useRpc } from "@/lib/use-rpc";

export const Route = createFileRoute("/_app/courses/")({ component: Courses });

function Courses() {
  const { data, loading, err, reload } = useRpc(() => listCourses());
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  if (loading) return <p className="text-muted">Đang tải khóa học…</p>;
  if (err) return <p className="text-accent">{err}</p>;
  const can = data?.me.canCreateCourse;

  async function onCreate(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    try {
      const r = await saveCourse({ data: { title: String(fd.get("title") || ""), description: String(fd.get("description") || "") } });
      toast.success("Đã tạo khóa (chưa công bố).");
      setOpen(false);
      reload();
      await nav({ to: "/courses/$id", params: { id: r.id } });
    } catch (er) { toast.error(errorMessage(er)); }
  }

  return (
    <div>
      <PageHeader kicker="Học thuật" title="Khóa học" desc="Video, từ vựng, Drive. Bấm một khóa để xem bài học." action={can ? <Button onClick={() => setOpen((v) => !v)}>{open ? "Đóng form" : "Tạo khóa"}</Button> : undefined} />
      {open && can ? (
        <form onSubmit={onCreate} className="card-paper mb-6 space-y-3 p-5">
          <Field label="Tên khóa"><Input name="title" required maxLength={LIMITS.title} /></Field>
          <Field label="Mô tả"><Textarea name="description" maxLength={LIMITS.description} /></Field>
          <Button type="submit">Lưu</Button>
        </form>
      ) : null}
      {(data?.rows.length ?? 0) === 0 ? <EmptyState title="Chưa có khóa công bố" /> : (
        <div className="grid gap-3 md:grid-cols-2">
          {data!.rows.map((c) => (
            <Link key={c.id} to="/courses/$id" params={{ id: c.id }} className="card-paper block p-5 hover:border-ink/30">
              <p className="font-display text-2xl break-words">{c.title}</p>
              <p className="mt-1 line-clamp-3 text-sm text-muted">{c.description}</p>
              <p className="mt-2 text-xs">{c.is_public ? "Công khai" : "Nháp"}</p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

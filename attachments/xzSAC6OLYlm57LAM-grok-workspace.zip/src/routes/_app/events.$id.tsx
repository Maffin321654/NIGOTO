import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import { QrBlock } from "@/components/qr-block";
import { Toggle } from "@/components/toggle";
import { Button } from "@/components/ui/button";
import { EVENT_TYPES, labelOf } from "@/lib/constants";
import { formatDateTime } from "@/lib/format";
import { deleteEvent, getEvent, joinEvent, setCheckinOpen, setEventPublic } from "@/lib/server/fns";
import { errorMessage } from "@/lib/utils";
import { useRpc } from "@/lib/use-rpc";

export const Route = createFileRoute("/_app/events/$id")({ component: EventDetail });

function EventDetail() {
  const { id } = Route.useParams();
  const { data, loading, err, reload } = useRpc(() => getEvent({ data: { id } }), [id]);
  if (loading) return <p className="text-muted">Đang tải sự kiện…</p>;
  if (err || !data) return <p className="text-accent">{err}</p>;

  const qrUrl = typeof window !== "undefined" ? `${window.location.origin}/checkin/${data.id}` : "";

  return (
    <div>
      <PageHeader kicker="Chi tiết sự kiện" title={data.title} desc={`${formatDateTime(data.start_at)} · ${data.location || "—"}`} />
      {data.cover_url ? <img src={data.cover_url} alt="" className="mb-5 max-h-72 w-full rounded-3xl object-cover" /> : null}
      <p className="max-w-3xl whitespace-pre-wrap break-words text-muted">{data.description}</p>
      <p className="mt-2 text-sm">{labelOf(EVENT_TYPES, data.event_type)} · {data.is_public ? "Đã công bố" : "Chưa công bố"}</p>
      <div className="mt-4 flex flex-wrap gap-2">
        {!data.iJoined ? <Button onClick={async () => { try { await joinEvent({ data: { id } }); toast.success("Đã đăng ký tham gia."); reload(); } catch (e) { toast.error(errorMessage(e)); } }}>Tham gia</Button> : <span className="self-center text-sm text-muted">Bạn đã đăng ký.</span>}
        {data.canPublish ? (
          <Button variant="ink" onClick={async () => { await setEventPublic({ data: { id, is_public: !data.is_public } }); reload(); }}>
            {data.is_public ? "Ẩn sự kiện" : "Công bố"}
          </Button>
        ) : null}
        {data.canEdit ? (
          <Button variant="danger" onClick={async () => {
            if (!confirm("Xóa sự kiện này?")) return;
            await deleteEvent({ data: { id } });
            window.location.assign("/events");
          }}>Xóa</Button>
        ) : null}
      </div>
      <div className="mt-6 grid gap-4 md:grid-cols-3">
        <div className="card-paper p-5"><p className="kicker">Đăng ký</p><p className="font-display text-3xl tabular-nums">{data.joined}</p></div>
        <div className="card-paper p-5"><p className="kicker">Đã điểm danh</p><p className="font-display text-3xl tabular-nums">{data.attended}</p></div>
        <div className="card-paper p-5"><p className="kicker">Bạn</p><p>{data.iAttended ? "Đã điểm danh" : "Chưa điểm danh"}</p></div>
      </div>
      {data.canCheckinToggle ? (
        <div className="card-paper mt-6 grid gap-4 p-5 md:grid-cols-2">
          <div>
            <Toggle on={data.checkin_open} onChange={async (v) => { await setCheckinOpen({ data: { id, open: v } }); reload(); }} label={data.checkin_open ? "Nhận thêm điểm danh" : "Không nhận thêm"} />
            <p className="mt-2 text-sm text-muted">QR chỉ hiện với ban quản trị. Thành viên quét mã này trên điện thoại.</p>
          </div>
          {qrUrl ? <QrBlock value={qrUrl} label={qrUrl} /> : null}
          <div className="md:col-span-2 space-y-2">
            {data.people.map((p) => (
              <div key={p.user_id} className="flex justify-between text-sm">
                <Link to="/members/$id" params={{ id: p.user_id }} className="hover:underline">{p.full_name}</Link>
                <span className="text-muted">{p.checked_at ? "Đã điểm danh" : "Chưa"}</span>
              </div>
            ))}
          </div>
        </div>
      ) : null}
      <p className="mt-4"><Link to="/events" className="text-sm underline">← Sự kiện</Link></p>
    </div>
  );
}

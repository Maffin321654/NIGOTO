import { createFileRoute, Link } from "@tanstack/react-router";
import { toast } from "sonner";
import { PageHeader } from "@/components/page-header";
import { Field } from "@/components/field";
import { Button } from "@/components/ui/button";
import { Input, Select, Textarea } from "@/components/ui/input";
import { deleteCourse, deleteCourseItem, getCourse, saveCourseItem, setCoursePublic } from "@/lib/server/fns";
import { errorMessage } from "@/lib/utils";
import { useRpc } from "@/lib/use-rpc";

export const Route = createFileRoute("/_app/courses/$id")({ component: CourseDetail });

function CourseDetail() {
  const { id } = Route.useParams();
  const { data, loading, err, reload } = useRpc(() => getCourse({ data: { id } }), [id]);
  if (loading) return <p className="text-muted">Đang tải khóa…</p>;
  if (err || !data) return <p className="text-accent">{err}</p>;

  async function addItem(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const kind = String(fd.get("kind") || "VOCAB");
    let extra = "";
    if (kind === "VOCAB") {
      extra = JSON.stringify({
        word: String(fd.get("word") || ""),
        reading: String(fd.get("reading") || ""),
        meaning: String(fd.get("meaning") || ""),
        example: String(fd.get("example") || ""),
      });
    }
    try {
      await saveCourseItem({
        data: {
          courseId: id,
          kind,
          title: String(fd.get("title") || ""),
          media_url: String(fd.get("media_url") || "") || undefined,
          extra: extra || undefined,
        },
      });
      toast.success("Đã thêm bài.");
      (e.target as HTMLFormElement).reset();
      reload();
    } catch (er) { toast.error(errorMessage(er)); }
  }

  return (
    <div>
      <PageHeader kicker="Chi tiết khóa" title={data.title} desc={data.description} />
      {data.canEdit ? (
        <div className="mb-4 flex gap-2">
          <Button variant="ink" onClick={async () => { await setCoursePublic({ data: { id, is_public: !data.is_public } }); reload(); }}>{data.is_public ? "Ẩn khóa" : "Công bố"}</Button>
          <Button variant="danger" onClick={async () => { if (!confirm("Xóa khóa này?")) return; await deleteCourse({ data: { id } }); window.location.assign("/courses"); }}>Xóa</Button>
        </div>
      ) : null}
      <div className="space-y-3">
        {data.items.map((it) => {
          const extra = it.extra ? safeJson(it.extra) : null;
          return (
            <article key={it.id} className="card-paper p-5">
              <p className="kicker">{it.kind}</p>
              <p className="font-display text-xl">{it.title}</p>
              {it.kind === "DRIVE" && it.media_url ? <a className="text-accent underline" href={it.media_url} target="_blank" rel="noreferrer">Mở Drive</a> : null}
              {it.kind === "VIDEO" && it.media_url ? <video src={it.media_url} controls className="mt-2 w-full rounded-xl" /> : null}
              {extra ? <p className="mt-2 text-sm">{extra.word} {extra.reading ? `（${extra.reading}）` : ""} — {extra.meaning}<br />{extra.example}</p> : null}
              {data.canEdit ? <Button variant="ghost" className="mt-2" onClick={async () => { await deleteCourseItem({ data: { id: it.id } }); reload(); }}>Xóa bài</Button> : null}
            </article>
          );
        })}
      </div>
      {data.canEdit ? (
        <form onSubmit={addItem} className="card-paper mt-6 grid gap-3 p-5 md:grid-cols-2">
          <Field label="Loại bài">
            <Select name="kind" defaultValue="VOCAB">
              <option value="VOCAB">Từ vựng</option>
              <option value="VIDEO">Video</option>
              <option value="DRIVE">Google Drive</option>
            </Select>
          </Field>
          <Field label="Tiêu đề bài"><Input name="title" required /></Field>
          <Field label="URL video / Drive"><Input name="media_url" placeholder="https://" /></Field>
          <Field label="Từ"><Input name="word" /></Field>
          <Field label="Cách đọc"><Input name="reading" /></Field>
          <Field label="Nghĩa"><Input name="meaning" /></Field>
          <div className="md:col-span-2"><Field label="Ví dụ"><Textarea name="example" /></Field></div>
          <Button type="submit">Thêm bài</Button>
        </form>
      ) : null}
      <p className="mt-4"><Link to="/courses" className="text-sm underline">← Khóa học</Link></p>
    </div>
  );
}

function safeJson(s: string) {
  try { return JSON.parse(s) as { word?: string; reading?: string; meaning?: string; example?: string }; } catch { return null; }
}

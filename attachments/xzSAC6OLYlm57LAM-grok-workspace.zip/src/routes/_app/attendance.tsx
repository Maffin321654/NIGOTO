import { createFileRoute, Link } from "@tanstack/react-router";
import { PageHeader } from "@/components/page-header";
import { QrBlock } from "@/components/qr-block";
import { Toggle } from "@/components/toggle";
import { formatDateTime } from "@/lib/format";
import { listAttendanceEvents, setCheckinOpen } from "@/lib/server/fns";
import { useRpc } from "@/lib/use-rpc";

export const Route = createFileRoute("/_app/attendance")({ component: Attendance });

function Attendance() {
  const { data, loading, err, reload } = useRpc(() => listAttendanceEvents());
  if (loading) return <p className="text-muted">Đang tải điểm danh…</p>;
  if (err || !data) return <p className="text-accent">{err}</p>;
  const staff = data.me.canToggleCheckin;
  const origin = typeof window !== "undefined" ? window.location.origin : "";

  return (
    <div>
      <PageHeader
        kicker="Check-in"
        title="Điểm danh"
        desc={staff ? "QR chỉ hiện với ban quản trị. Bật/tắt nhận điểm danh từng sự kiện." : "Quét mã QR do ban quản trị đưa. Sau khi quét bạn sẽ thấy Đã điểm danh."}
      />
      <div className="space-y-4">
        {data.events.map((e) => (
          <article key={e.id} className="card-paper p-5">
            <div className="flex flex-wrap items-start justify-between gap-4">
              <div>
                <Link to="/events/$id" params={{ id: e.id }} className="font-display text-2xl hover:underline">{e.title}</Link>
                <p className="text-sm text-muted">{formatDateTime(e.start_at)} · {e.location || "—"}</p>
                {staff ? <p className="mt-1 text-sm">Đã điểm danh: {e.attended_count}</p> : (
                  <p className="mt-3 font-medium">{e.attended ? "Đã điểm danh" : "Quét mã QR do ban quản trị"}</p>
                )}
              </div>
              {staff ? (
                <div className="flex flex-col items-end gap-3">
                  <Toggle
                    on={e.checkin_open}
                    onChange={async (v) => { await setCheckinOpen({ data: { id: e.id, open: v } }); reload(); }}
                    label={e.checkin_open ? "Nhận thêm điểm danh" : "Không nhận thêm"}
                  />
                  {origin ? <QrBlock value={`${origin}/checkin/${e.id}`} /> : null}
                </div>
              ) : null}
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}

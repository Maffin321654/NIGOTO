import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { authClient, authEnabled } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { saveSignupIdentity } from "@/lib/server/fns";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Field } from "@/components/field";
import { errorMessage, isPersonalEmail } from "@/lib/utils";

export const Route = createFileRoute("/login")({ component: Login });

function nextPath() {
  if (typeof window === "undefined") return "/";
  const n = sessionStorage.getItem("nigoto_next");
  sessionStorage.removeItem("nigoto_next");
  return n && n.startsWith("/") ? n : "/";
}

function Login() {
  const nav = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [studentId, setStudentId] = useState("");
  const [birthday, setBirthday] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!isPending && user) nav({ to: nextPath() });
  }, [isPending, user, nav]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!authEnabled) return;
    if (!isPersonalEmail(email)) {
      toast.error("Dùng email cá nhân hợp lệ.");
      return;
    }
    setBusy(true);
    try {
      if (mode === "in") {
        const res = await authClient.signIn.email({ email, password });
        if (res.error) throw new Error(res.error.message || "Đăng nhập thất bại.");
      } else {
        if (password.length < 8) throw new Error("Mật khẩu tối thiểu 8 ký tự.");
        const res = await authClient.signUp.email({ email, password, name: fullName.trim() });
        if (res.error) throw new Error(res.error.message || "Đăng ký thất bại.");
        await saveSignupIdentity({ data: { fullName, studentId, birthday } });
      }
      window.location.assign(nextPath());
    } catch (err) {
      toast.error(errorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="grid min-h-screen place-items-center bg-paper px-4">
      <div className="w-full max-w-md">
        <p className="kicker">Câu lạc bộ Nhật ngữ</p>
        <h1 className="mt-2 font-display text-4xl text-ink">Nigoto Hub</h1>
        <p className="mt-1 text-muted">Đăng nhập bằng email cá nhân và mật khẩu.</p>
        <form onSubmit={onSubmit} className="card-paper mt-6 space-y-4 p-6">
          {mode === "up" ? (
            <>
              <Field label="Họ tên">
                <Input value={fullName} onChange={(e) => setFullName(e.target.value)} maxLength={30} required />
              </Field>
              <Field label="MSSV">
                <Input value={studentId} onChange={(e) => setStudentId(e.target.value)} placeholder="524H0087" required />
              </Field>
              <Field label="Ngày sinh">
                <Input type="date" value={birthday} onChange={(e) => setBirthday(e.target.value)} required />
              </Field>
            </>
          ) : null}
          <Field label="Email cá nhân">
            <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required autoComplete="email" />
          </Field>
          <Field label="Mật khẩu">
            <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} autoComplete={mode === "in" ? "current-password" : "new-password"} />
          </Field>
          <Button type="submit" disabled={busy || !authEnabled} className="w-full">
            {busy ? "Đang xử lý…" : mode === "in" ? "Đăng nhập" : "Tạo tài khoản"}
          </Button>
          <button type="button" className="w-full text-sm text-muted underline" onClick={() => setMode(mode === "in" ? "up" : "in")}>
            {mode === "in" ? "Chưa có tài khoản? Đăng ký" : "Đã có tài khoản? Đăng nhập"}
          </button>
        </form>
      </div>
    </main>
  );
}

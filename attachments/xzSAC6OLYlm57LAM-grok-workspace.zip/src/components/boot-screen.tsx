import { useEffect, useState } from "react";

export function BootScreen() {
  const [slow, setSlow] = useState(false);
  useEffect(() => {
    const t = window.setTimeout(() => setSlow(true), 6000);
    return () => window.clearTimeout(t);
  }, []);
  return (
    <div className="grid min-h-screen place-items-center bg-paper p-6 text-center">
      <div>
        <p className="font-display text-2xl text-ink">Nigoto Hub</p>
        <p className="mt-2 text-sm text-muted">Đang mở workspace…</p>
        {slow ? (
          <button
            className="mt-4 rounded-full bg-accent px-4 py-2 text-sm font-semibold text-paper-3"
            onClick={() => window.location.reload()}
          >
            Tải lại
          </button>
        ) : null}
      </div>
    </div>
  );
}

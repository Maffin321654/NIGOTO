import type { ReactNode } from "react";

export function PageHeader({
  kicker,
  title,
  desc,
  action,
}: {
  kicker: string;
  title: string;
  desc?: string;
  action?: ReactNode;
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        <p className="kicker">{kicker}</p>
        <h1 className="mt-1 font-display text-4xl tracking-tight text-ink">{title}</h1>
        {desc ? <p className="mt-1 text-muted">{desc}</p> : null}
      </div>
      {action}
    </div>
  );
}

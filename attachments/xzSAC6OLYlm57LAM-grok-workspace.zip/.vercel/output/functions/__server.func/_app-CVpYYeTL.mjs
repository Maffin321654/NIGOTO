import { o as __toESM } from "./_runtime.mjs";
import { C as require_jsx_runtime, U as require_react, b as Navigate, f as useRouterState, h as Outlet, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { b as errorMessage, v as cn } from "./_ssr/utils-D7h6xKRb.mjs";
import { D as listNotifications, _ as globalSearch, h as getMe } from "./_ssr/fns-BZr3NIHM.mjs";
import { r as signOut } from "./_ssr/client-DUtYoQbQ.mjs";
import { i as hasGateSessionMarker } from "./_ssr/server-2GfYQS84.mjs";
import { n as useCurrentUserState, t as useCurrentUser } from "./_ssr/use-current-user-X89NvhzM.mjs";
import { i as Menu, r as Search, s as Bell, t as X } from "./_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app-CVpYYeTL.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/** Render children only when a user is present (real session, or the disabled-auth dev user). */
function SignedIn({ children }) {
	const { user } = useCurrentUserState();
	return user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children }) : null;
}
/**
* Render children only once we KNOW the visitor is signed out (`isPending` has
* cleared and there is no user). Hidden while the session is still loading.
*/
function SignedOut({ children }) {
	const { user, isPending } = useCurrentUserState();
	if (isPending || user) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
function BootScreen() {
	const [slow, setSlow] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const t = window.setTimeout(() => setSlow(true), 6e3);
		return () => window.clearTimeout(t);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-screen place-items-center bg-paper p-6 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl text-ink",
				children: "Nigoto Hub"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Đang mở workspace…"
			}),
			slow ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "mt-4 rounded-full bg-accent px-4 py-2 text-sm font-semibold text-paper-3",
				onClick: () => window.location.reload(),
				children: "Tải lại"
			}) : null
		] })
	});
}
var NAV = [
	{
		to: "/",
		label: "Dashboard",
		show: () => true
	},
	{
		to: "/members",
		label: "Thành viên",
		show: () => true
	},
	{
		to: "/departments",
		label: "Ban",
		show: () => true
	},
	{
		to: "/events",
		label: "Sự kiện",
		show: () => true
	},
	{
		to: "/courses",
		label: "Khóa học",
		show: () => true
	},
	{
		to: "/notifications",
		label: "Thông báo",
		show: () => true
	},
	{
		to: "/tasks",
		label: "Công việc",
		show: (m) => m.canViewStaff
	},
	{
		to: "/media",
		label: "Media",
		show: (m) => m.canViewMedia
	},
	{
		to: "/calendar",
		label: "Lịch",
		show: (m) => m.canViewCalendar
	},
	{
		to: "/attendance",
		label: "Điểm danh",
		show: () => true
	},
	{
		to: "/analytics",
		label: "Thống kê",
		show: (m) => m.canViewStaff
	},
	{
		to: "/huong-dan",
		label: "Hướng dẫn",
		show: () => true
	},
	{
		to: "/settings",
		label: "Hồ sơ",
		show: () => true
	}
];
function AppShell({ children }) {
	const [me, setMe] = (0, import_react.useState)(null);
	const [bootErr, setBootErr] = (0, import_react.useState)(null);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [q, setQ] = (0, import_react.useState)("");
	const [hits, setHits] = (0, import_react.useState)(null);
	const [unread, setUnread] = (0, import_react.useState)(0);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	(0, import_react.useEffect)(() => {
		let live = true;
		let resolved = false;
		const t = window.setTimeout(() => {
			if (live && !resolved) setBootErr("Phiên tải quá lâu. Hãy tải lại trang.");
		}, 8e3);
		getMe().then((m) => {
			resolved = true;
			if (!live) return;
			setMe(m);
			setBootErr(null);
		}).catch((e) => {
			resolved = true;
			if (live) setBootErr(errorMessage(e, "Không tải được phiên."));
		});
		return () => {
			live = false;
			window.clearTimeout(t);
		};
	}, []);
	(0, import_react.useEffect)(() => {
		listNotifications().then((n) => setUnread(n.unread)).catch(() => {});
	}, [pathname]);
	(0, import_react.useEffect)(() => {
		if (typeof window === "undefined") return;
		if (pathname.startsWith("/checkin/")) sessionStorage.setItem("nigoto_next", pathname);
	}, [pathname]);
	(0, import_react.useEffect)(() => {
		if (q.trim().length < 2) {
			setHits(null);
			return;
		}
		const t = setTimeout(() => {
			globalSearch({ data: { q } }).then(setHits).catch(() => setHits(null));
		}, 220);
		return () => clearTimeout(t);
	}, [q]);
	const items = (0, import_react.useMemo)(() => me ? NAV.filter((n) => n.show(me)) : NAV.slice(0, 6), [me]);
	if (bootErr && !me) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid min-h-screen place-items-center bg-paper p-6 text-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl",
				children: "Nigoto Hub"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-accent",
				children: bootErr
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				className: "mt-4 rounded-full bg-accent px-4 py-2 text-sm font-semibold text-paper-3",
				onClick: () => window.location.reload(),
				children: "Tải lại"
			})
		] })
	});
	if (!me) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {});
	const side = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-5 py-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl text-paper-3",
					children: "Nigoto"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs tracking-[0.18em] text-gold uppercase",
					children: "日本語 Hub"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "min-h-0 flex-1 space-y-0.5 overflow-y-auto px-3 pb-6",
				children: items.map((n) => {
					const active = n.to === "/" ? pathname === "/" : pathname === n.to || pathname.startsWith(`${n.to}/`);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: n.to,
						onClick: () => setOpen(false),
						className: cn("block rounded-xl px-3 py-2.5 text-sm min-h-11", active ? "bg-paper-3/15 text-paper-3" : "text-paper-3/75 hover:bg-paper-3/10 hover:text-paper-3"),
						children: n.label
					}, n.to);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-paper-3/10 px-4 py-4 text-sm text-paper-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate font-medium",
					children: me.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-xs text-paper-3/60",
					children: me.depts[0]?.name ?? "Thành viên"
				})]
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-paper md:grid md:grid-cols-[240px_1fr]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "sticky top-0 hidden h-screen bg-ink md:block",
				children: side
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40 md:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "absolute inset-0 bg-ink/40",
					onClick: () => setOpen(false),
					"aria-label": "Đóng menu"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
					className: "relative h-full w-[80%] max-w-xs bg-ink",
					children: side
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "sticky top-0 z-20 flex items-center gap-3 border-b border-line bg-paper/90 px-4 py-3 backdrop-blur",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: "md:hidden min-h-11 min-w-11",
							onClick: () => setOpen(true),
							"aria-label": "Mở menu",
							children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: q,
									onChange: (e) => setQ(e.target.value),
									placeholder: "Tìm thành viên, sự kiện…",
									className: "w-full rounded-full border border-line bg-paper-3 py-2.5 pl-10 pr-4 text-sm text-ink outline-none"
								}),
								hits ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute z-30 mt-2 w-full rounded-2xl border border-line bg-paper-3 p-3 shadow-lg",
									children: !hits.people.length && !hits.events.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-muted",
										children: "Không có kết quả."
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "space-y-2 text-sm",
										children: [hits.people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/members/$id",
											params: { id: p.user_id },
											className: "block rounded-lg px-2 py-1 hover:bg-paper-2",
											onClick: () => setQ(""),
											children: [
												p.full_name,
												" · ",
												p.student_id
											]
										}, p.user_id)), hits.events.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
											to: "/events/$id",
											params: { id: e.id },
											className: "block rounded-lg px-2 py-1 hover:bg-paper-2",
											onClick: () => setQ(""),
											children: ["Sự kiện · ", e.title]
										}, e.id))]
									})
								}) : null
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/notifications",
							className: "relative min-h-11 min-w-11 grid place-items-center",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-5" }), unread > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-1 top-1 h-2 w-2 rounded-full bg-accent" }) : null]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "px-4 py-6 md:px-8 md:py-8",
					children
				})]
			})
		]
	});
}
function AppLayout() {
	const { user, isPending } = useCurrentUserState();
	if (typeof window !== "undefined" && !isPending && !user) {
		const path = window.location.pathname;
		if (path.startsWith("/checkin/")) sessionStorage.setItem("nigoto_next", path);
	}
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BootScreen, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedOut, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedIn, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) })] });
}
//#endregion
export { AppLayout as component };

import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, U as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { x as listCalendar } from "./fns-BZr3NIHM.mjs";
import { n as useRpc, t as PageHeader } from "./use-rpc-ubY9dVF8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/calendar-CGBWi3RE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CalendarPage() {
	const { data, loading, err } = useRpc(() => listCalendar());
	const [cursor, setCursor] = (0, import_react.useState)(() => {
		const n = /* @__PURE__ */ new Date();
		return new Date(n.getFullYear(), n.getMonth(), 1);
	});
	const cells = (0, import_react.useMemo)(() => buildMonth(cursor), [cursor]);
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Đang tải lịch…"
	});
	if (err) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-accent",
		children: err
	});
	const items = data?.items ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Lịch CLB",
			title: cursor.toLocaleDateString("vi-VN", {
				month: "long",
				year: "numeric"
			}),
			desc: "Sự kiện và ngày đăng content.",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "rounded-full border border-line px-3 py-2",
					onClick: () => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1)),
					children: "Trước"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					className: "rounded-full border border-line px-3 py-2",
					onClick: () => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1)),
					children: "Sau"
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-7 gap-1 text-center text-xs uppercase tracking-wider text-muted",
			children: "CN T2 T3 T4 T5 T6 T7".split(" ").map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "py-2",
				children: d
			}, d))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid grid-cols-7 gap-1",
			children: cells.map((c, i) => {
				const dayItems = items.filter((it) => sameDay(it.start_at, c.date));
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: `min-h-24 rounded-xl border border-line p-1.5 ${c.inMonth ? "bg-paper-3" : "bg-paper-2/40 text-muted"}`,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs tabular-nums",
						children: c.date.getDate()
					}), dayItems.map((it) => it.kind === "event" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/events/$id",
						params: { id: it.id },
						className: "mt-1 block truncate rounded-md bg-accent/15 px-1 text-[11px] text-accent",
						children: it.title
					}, it.id) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 truncate rounded-md bg-ink/10 px-1 text-[11px]",
						children: it.title
					}, it.id))]
				}, i);
			})
		})
	] });
}
function sameDay(iso, d) {
	const x = new Date(iso);
	return x.getFullYear() === d.getFullYear() && x.getMonth() === d.getMonth() && x.getDate() === d.getDate();
}
function buildMonth(start) {
	const offset = new Date(start.getFullYear(), start.getMonth(), 1).getDay();
	const days = [];
	for (let i = 0; i < 42; i++) {
		const date = new Date(start.getFullYear(), start.getMonth(), i - offset + 1);
		days.push({
			date,
			inMonth: date.getMonth() === start.getMonth()
		});
	}
	return days;
}
//#endregion
export { CalendarPage as component };

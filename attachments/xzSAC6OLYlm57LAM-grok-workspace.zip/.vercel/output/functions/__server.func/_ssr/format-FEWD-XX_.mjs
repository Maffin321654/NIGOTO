//#region node_modules/.nitro/vite/services/ssr/assets/format-FEWD-XX_.js
function formatDate(iso) {
	if (!iso) return "—";
	const d = typeof iso === "string" ? new Date(iso) : iso;
	if (Number.isNaN(d.getTime())) return "—";
	return d.toLocaleDateString("vi-VN", {
		day: "2-digit",
		month: "2-digit",
		year: "numeric"
	});
}
function formatDateTime(iso) {
	if (!iso) return "—";
	const d = typeof iso === "string" ? new Date(iso) : iso;
	if (Number.isNaN(d.getTime())) return "—";
	return d.toLocaleString("vi-VN", {
		day: "2-digit",
		month: "2-digit",
		year: "numeric",
		hour: "2-digit",
		minute: "2-digit"
	});
}
function greeting() {
	const h = (/* @__PURE__ */ new Date()).getHours();
	if (h < 12) return "Chào buổi sáng";
	if (h < 18) return "Chào buổi chiều";
	return "Chào buổi tối";
}
//#endregion
export { formatDateTime as n, greeting as r, formatDate as t };

import { C as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as labelOf, a as EVENT_TYPES, b as errorMessage } from "./utils-D7h6xKRb.mjs";
import { B as setCheckinOpen, H as setEventPublic, m as getEvent, s as deleteEvent, v as joinEvent } from "./fns-BZr3NIHM.mjs";
import { n as useRpc, t as PageHeader } from "./use-rpc-ubY9dVF8.mjs";
import { n as formatDateTime } from "./format-FEWD-XX_.mjs";
import { t as Button } from "./button-naZWmM3u.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Toggle, t as QrBlock } from "./toggle-1NARaqJO.mjs";
import { r as Route$3 } from "./router-CtBY5V57.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/events._id-Db7GDCzl.js
var import_jsx_runtime = require_jsx_runtime();
function EventDetail() {
	const { id } = Route$3.useParams();
	const { data, loading, err, reload } = useRpc(() => getEvent({ data: { id } }), [id]);
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Đang tải sự kiện…"
	});
	if (err || !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-accent",
		children: err
	});
	const qrUrl = typeof window !== "undefined" ? `${window.location.origin}/checkin/${data.id}` : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Chi tiết sự kiện",
			title: data.title,
			desc: `${formatDateTime(data.start_at)} · ${data.location || "—"}`
		}),
		data.cover_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: data.cover_url,
			alt: "",
			className: "mb-5 max-h-72 w-full rounded-3xl object-cover"
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "max-w-3xl whitespace-pre-wrap break-words text-muted",
			children: data.description
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 text-sm",
			children: [
				labelOf(EVENT_TYPES, data.event_type),
				" · ",
				data.is_public ? "Đã công bố" : "Chưa công bố"
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex flex-wrap gap-2",
			children: [
				!data.iJoined ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: async () => {
						try {
							await joinEvent({ data: { id } });
							toast.success("Đã đăng ký tham gia.");
							reload();
						} catch (e) {
							toast.error(errorMessage(e));
						}
					},
					children: "Tham gia"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "self-center text-sm text-muted",
					children: "Bạn đã đăng ký."
				}),
				data.canPublish ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ink",
					onClick: async () => {
						await setEventPublic({ data: {
							id,
							is_public: !data.is_public
						} });
						reload();
					},
					children: data.is_public ? "Ẩn sự kiện" : "Công bố"
				}) : null,
				data.canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "danger",
					onClick: async () => {
						if (!confirm("Xóa sự kiện này?")) return;
						await deleteEvent({ data: { id } });
						window.location.assign("/events");
					},
					children: "Xóa"
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-4 md:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-paper p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: "Đăng ký"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl tabular-nums",
						children: data.joined
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-paper p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: "Đã điểm danh"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl tabular-nums",
						children: data.attended
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-paper p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: "Bạn"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: data.iAttended ? "Đã điểm danh" : "Chưa điểm danh" })]
				})
			]
		}),
		data.canCheckinToggle ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card-paper mt-6 grid gap-4 p-5 md:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
					on: data.checkin_open,
					onChange: async (v) => {
						await setCheckinOpen({ data: {
							id,
							open: v
						} });
						reload();
					},
					label: data.checkin_open ? "Nhận thêm điểm danh" : "Không nhận thêm"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: "QR chỉ hiện với ban quản trị. Thành viên quét mã này trên điện thoại."
				})] }),
				qrUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrBlock, {
					value: qrUrl,
					label: qrUrl
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "md:col-span-2 space-y-2",
					children: data.people.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/members/$id",
							params: { id: p.user_id },
							className: "hover:underline",
							children: p.full_name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: p.checked_at ? "Đã điểm danh" : "Chưa"
						})]
					}, p.user_id))
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/events",
				className: "text-sm underline",
				children: "← Sự kiện"
			})
		})
	] });
}
//#endregion
export { EventDetail as component };

import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, U as require_react, x as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as labelOf, T as toLocalInput, a as EVENT_TYPES, b as errorMessage, i as EVENT_STATUS, o as LIMITS, y as compressImage } from "./utils-D7h6xKRb.mjs";
import { L as saveEvent, T as listEvents, h as getMe } from "./fns-BZr3NIHM.mjs";
import { n as useRpc, t as PageHeader } from "./use-rpc-ubY9dVF8.mjs";
import { n as formatDateTime } from "./format-FEWD-XX_.mjs";
import { t as Button } from "./button-naZWmM3u.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./field-DNAamJBL.mjs";
import { n as Select, r as Textarea, t as Input } from "./input-FeVPt8tT.mjs";
import { t as EmptyState } from "./empty-state-B_Ow87ZB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/events.index-CfP4nAgc.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Events() {
	const me = useRpc(() => getMe());
	const { data, loading, err, reload } = useRpc(() => listEvents());
	const nav = useNavigate();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [cover, setCover] = (0, import_react.useState)("");
	if (loading || me.loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Đang tải sự kiện…"
	});
	if (err) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-accent",
		children: err
	});
	const can = me.data?.canCreateEvent;
	async function onCreate(e) {
		e.preventDefault();
		const fd = new FormData(e.currentTarget);
		try {
			const saved = await saveEvent({ data: {
				title: String(fd.get("title") || ""),
				description: String(fd.get("description") || ""),
				event_type: String(fd.get("event_type") || "CULTURE"),
				status: String(fd.get("status") || "UPCOMING"),
				location: String(fd.get("location") || ""),
				start_at: new Date(String(fd.get("start_at"))).toISOString(),
				end_at: fd.get("end_at") ? new Date(String(fd.get("end_at"))).toISOString() : void 0,
				cover_url: cover || void 0,
				is_public: fd.get("is_public") === "on"
			} });
			toast.success("Đã lưu sự kiện.");
			setOpen(false);
			reload();
			await nav({
				to: "/events/$id",
				params: { id: saved.id }
			});
		} catch (er) {
			toast.error(errorMessage(er));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Hoạt động",
			title: "Sự kiện",
			desc: "Bấm một sự kiện để xem chi tiết, điểm danh và công bố.",
			action: can ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setOpen((v) => !v),
				children: open ? "Đóng form" : "Tạo sự kiện"
			}) : void 0
		}),
		open && can ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: onCreate,
			className: "card-paper mb-6 grid gap-3 p-5 md:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Tên sự kiện",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "title",
						required: true,
						maxLength: LIMITS.title
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Địa điểm",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { name: "location" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Loại",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						name: "event_type",
						children: EVENT_TYPES.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: t.id,
							children: t.label
						}, t.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Trạng thái",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						name: "status",
						children: EVENT_STATUS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: t.id,
							children: t.label
						}, t.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Bắt đầu",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "start_at",
						type: "datetime-local",
						required: true,
						defaultValue: toLocalInput(/* @__PURE__ */ new Date())
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Kết thúc",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "end_at",
						type: "datetime-local"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "md:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Mô tả",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							name: "description",
							maxLength: LIMITS.description
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Ảnh bìa",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						type: "file",
						accept: "image/*",
						onChange: async (e) => {
							const f = e.target.files?.[0];
							if (!f) return;
							setCover(await compressImage(f));
						}
					})
				}),
				cover ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: cover,
					alt: "",
					className: "h-28 w-full rounded-xl object-cover"
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex items-center gap-2 text-sm md:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "checkbox",
						name: "is_public"
					}), " Hiện cho thành viên"]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2 md:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Lưu"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "ghost",
						onClick: () => setOpen(false),
						children: "Hủy"
					})]
				})
			]
		}) : null,
		(data ?? []).length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Chưa có sự kiện",
			hint: "Ban Sự kiện hoặc Ban Chủ nhiệm có thể tạo."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 md:grid-cols-2",
			children: (data ?? []).map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/events/$id",
				params: { id: e.id },
				className: "card-paper overflow-hidden hover:border-ink/30",
				children: [e.cover_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: e.cover_url,
					alt: "",
					className: "h-36 w-full object-cover"
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl break-words",
							children: e.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm text-muted",
							children: [
								formatDateTime(e.start_at),
								" · ",
								labelOf(EVENT_TYPES, e.event_type)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs",
							children: e.is_public ? "Đã công bố" : "Nháp / ẩn"
						})
					]
				})]
			}, e.id))
		})
	] });
}
//#endregion
export { Events as component };

import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, U as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as labelOf, T as toLocalInput, b as errorMessage, n as CONTENT_TYPES, o as LIMITS, s as PLATFORMS, t as CONTENT_STATUS } from "./utils-D7h6xKRb.mjs";
import { M as reviewContent, P as saveContent, S as listContent, T as listEvents, h as getMe, i as deleteContent } from "./fns-BZr3NIHM.mjs";
import { n as useRpc, t as PageHeader } from "./use-rpc-ubY9dVF8.mjs";
import { n as formatDateTime } from "./format-FEWD-XX_.mjs";
import { t as Button } from "./button-naZWmM3u.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { o as CalendarClock } from "../_libs/lucide-react.mjs";
import { t as Field } from "./field-DNAamJBL.mjs";
import { n as Select, r as Textarea, t as Input } from "./input-FeVPt8tT.mjs";
import { t as EmptyState } from "./empty-state-B_Ow87ZB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/media-DdOtuV0A.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Media() {
	const me = useRpc(() => getMe());
	const { data, loading, err, reload } = useRpc(() => listContent());
	const events = useRpc(() => listEvents());
	const [open, setOpen] = (0, import_react.useState)(true);
	const [publishAt, setPublishAt] = (0, import_react.useState)(() => toLocalInput(new Date(Date.now() + 36e5)));
	const can = me.data?.canCreateContent ?? data?.me.canCreateContent;
	async function onCreate(e) {
		e.preventDefault();
		const fd = new FormData(e.currentTarget);
		const publish = String(fd.get("publish_at") || publishAt || "");
		if (!publish) {
			toast.error("Phải chọn ngày giờ đăng trên lịch.");
			return;
		}
		try {
			await saveContent({ data: {
				title: String(fd.get("title") || ""),
				caption: String(fd.get("caption") || ""),
				platform: String(fd.get("platform") || "FACEBOOK"),
				content_type: String(fd.get("content_type") || "POSTER"),
				publish_at: new Date(publish).toISOString(),
				event_id: String(fd.get("event_id") || "") || void 0,
				status: String(fd.get("status") || "IDEA")
			} });
			toast.success("Đã tạo content và ghi vào lịch đăng.");
			setOpen(false);
			reload();
		} catch (er) {
			toast.error(errorMessage(er));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Truyền thông",
			title: "Media Center",
			desc: "Tạo content, bắt buộc chọn ngày giờ đăng — mục sẽ hiện trên lịch CLB.",
			action: can ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setOpen((v) => !v),
				children: open ? "Đóng form" : "Tạo content"
			}) : void 0
		}),
		can && open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: onCreate,
			className: "card-paper mb-6 grid gap-3 p-5 md:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Tiêu đề",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "title",
						required: true,
						maxLength: LIMITS.title,
						placeholder: "Poster Tanabata"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nền tảng",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						name: "platform",
						children: PLATFORMS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: p.id,
							children: p.label
						}, p.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Loại nội dung",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						name: "content_type",
						children: CONTENT_TYPES.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: p.id,
							children: p.label
						}, p.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block space-y-1.5 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex items-center gap-2 font-medium text-ink",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CalendarClock, { className: "size-4 text-accent" }), "Ngày giờ đăng (lịch) *"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							name: "publish_at",
							type: "datetime-local",
							required: true,
							value: publishAt,
							onChange: (e) => setPublishAt(e.target.value)
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs text-muted",
							children: "Bắt buộc. Content sẽ hiện trên trang Lịch đúng ngày giờ này."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Gắn sự kiện (tuỳ chọn)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						name: "event_id",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "",
							children: "Không gắn"
						}), (events.data ?? []).map((ev) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: ev.id,
							children: ev.title
						}, ev.id))]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Trạng thái ban đầu",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						name: "status",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "IDEA",
							children: "Ý tưởng"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "SUBMITTED",
							children: "Gửi duyệt ngay"
						})]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "md:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Caption / mô tả",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							name: "caption",
							maxLength: LIMITS.description,
							required: true
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2 md:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							children: "Lưu content vào lịch"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							onClick: () => setOpen(false),
							children: "Hủy"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/calendar",
							className: "text-sm text-muted underline",
							children: "Xem lịch CLB"
						})
					]
				})
			]
		}) : null,
		loading && !data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-muted",
			children: "Đang tải Media Center…"
		}) : null,
		err ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-accent",
			children: err
		}) : null,
		(data?.items.length ?? 0) === 0 && !loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, {
			title: "Chưa có content",
			hint: "Bấm Tạo content, điền ngày giờ đăng trên lịch."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: (data?.items ?? []).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
				className: "card-paper p-5",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl break-words",
							children: c.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [
								labelOf(PLATFORMS, c.platform),
								" · ",
								labelOf(CONTENT_TYPES, c.content_type),
								" · ",
								labelOf(CONTENT_STATUS, c.status)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: "Lịch đăng: "
							}), c.publish_at ? formatDateTime(c.publish_at) : "Chưa đặt"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 whitespace-pre-wrap break-words text-sm",
							children: c.caption
						})
					] }), can ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							c.status === "IDEA" || c.status === "CHANGES" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: async () => {
									await reviewContent({ data: {
										id: c.id,
										action: "SUBMIT",
										comment: ""
									} });
									reload();
								},
								children: "Gửi duyệt"
							}) : null,
							c.status === "SUBMITTED" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									onClick: async () => {
										await reviewContent({ data: {
											id: c.id,
											action: "APPROVE",
											comment: "OK"
										} });
										reload();
									},
									children: "Duyệt"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									onClick: async () => {
										const comment = prompt("Ghi chú yêu cầu sửa") || "";
										if (!comment) return;
										await reviewContent({ data: {
											id: c.id,
											action: "CHANGES",
											comment
										} });
										reload();
									},
									children: "Yêu cầu sửa"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "danger",
									onClick: async () => {
										const comment = prompt("Lý do từ chối") || "";
										if (!comment) return;
										await reviewContent({ data: {
											id: c.id,
											action: "REJECT",
											comment
										} });
										reload();
									},
									children: "Từ chối"
								})
							] }) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								onClick: async () => {
									if (!confirm("Xóa content này?")) return;
									await deleteContent({ data: { id: c.id } });
									reload();
								},
								children: "Xóa"
							})
						]
					}) : null]
				})
			}, c.id))
		})
	] });
}
//#endregion
export { Media as component };

import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, U as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as errorMessage } from "./utils-D7h6xKRb.mjs";
import { n as checkinEvent } from "./fns-BZr3NIHM.mjs";
import { o as Route$9 } from "./router-CtBY5V57.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/checkin._eventId-B-nYztXV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Checkin() {
	const { eventId } = Route$9.useParams();
	const [state, setState] = (0, import_react.useState)("pending");
	const [msg, setMsg] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		checkinEvent({ data: {
			eventId,
			method: "QR"
		} }).then((r) => {
			setState("ok");
			setMsg(r.title);
		}).catch((e) => {
			setState("err");
			setMsg(errorMessage(e));
		});
	}, [eventId]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-lg py-10 text-center",
		children: [
			state === "pending" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "Đang điểm danh…"
			}) : null,
			state === "ok" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "Thành công"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-4xl",
					children: "Đã điểm danh"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: msg
				})
			] }) : null,
			state === "err" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl",
				children: "Chưa điểm danh được"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-accent",
				children: msg
			})] }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/attendance",
				className: "mt-6 inline-block underline",
				children: "Về trang điểm danh"
			})
		]
	});
}
//#endregion
export { Checkin as component };

import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { v as cn } from "./utils-D7h6xKRb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/button-naZWmM3u.js
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 rounded-full px-4 py-2 text-sm font-semibold transition disabled:opacity-50 min-h-11", {
	variants: { variant: {
		primary: "bg-accent text-paper-3 hover:opacity-90",
		ink: "bg-ink text-paper-3 hover:opacity-90",
		ghost: "border border-line bg-paper-3 text-ink hover:bg-paper-2",
		danger: "bg-accent/15 text-accent hover:bg-accent/25"
	} },
	defaultVariants: { variant: "primary" }
});
function Button({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		className: cn(buttonVariants({ variant }), className),
		...props
	});
}
//#endregion
export { Button as t };

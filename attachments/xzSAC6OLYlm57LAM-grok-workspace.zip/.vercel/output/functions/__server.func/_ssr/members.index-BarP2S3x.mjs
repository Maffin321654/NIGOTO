import { C as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { d as ROLE_LABEL, p as STATUS_LABEL } from "./utils-D7h6xKRb.mjs";
import { E as listMembers } from "./fns-BZr3NIHM.mjs";
import { n as useRpc, t as PageHeader } from "./use-rpc-ubY9dVF8.mjs";
import { a as ChevronRight } from "../_libs/lucide-react.mjs";
import { t as EmptyState } from "./empty-state-B_Ow87ZB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/members.index-BarP2S3x.js
var import_jsx_runtime = require_jsx_runtime();
function Members() {
	const { data, loading, err } = useRpc(() => listMembers());
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Đang tải…"
	});
	if (err) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-accent",
		children: err
	});
	const rows = data ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		kicker: "Nhân sự",
		title: "Thành viên",
		desc: "Danh sách toàn CLB. Bấm một người để xem hồ sơ chi tiết."
	}), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, { title: "Chưa có thành viên" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card-paper overflow-hidden",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "hidden grid-cols-12 gap-2 border-b border-line px-5 py-3 text-xs uppercase tracking-wider text-muted md:grid",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "col-span-4",
					children: "Họ tên"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "col-span-2",
					children: "MSSV"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "col-span-3",
					children: "Ban"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "col-span-2",
					children: "Vai trò"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "col-span-1" })
			]
		}), rows.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/members/$id",
			params: { id: m.user_id },
			className: "grid grid-cols-[1fr_auto] gap-1 border-b border-line px-5 py-4 last:border-0 hover:bg-paper-2 md:grid-cols-12 md:items-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-medium break-words md:col-span-4",
					children: m.full_name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-sm text-muted md:col-span-2",
					children: m.student_id
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted md:col-span-3",
					children: m.depts || "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "text-sm md:col-span-2",
					children: [
						ROLE_LABEL[m.role] ?? m.role,
						" · ",
						STATUS_LABEL[m.status] ?? m.status
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "hidden justify-end text-muted md:col-span-1 md:flex",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "size-4" })
				})
			]
		}, m.user_id))]
	})] });
}
//#endregion
export { Members as component };

import { C as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as errorMessage } from "./utils-D7h6xKRb.mjs";
import { I as saveCourseItem, V as setCoursePublic, a as deleteCourse, d as getCourse, o as deleteCourseItem } from "./fns-BZr3NIHM.mjs";
import { n as useRpc, t as PageHeader } from "./use-rpc-ubY9dVF8.mjs";
import { t as Button } from "./button-naZWmM3u.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as Route$7 } from "./router-CtBY5V57.mjs";
import { t as Field } from "./field-DNAamJBL.mjs";
import { n as Select, r as Textarea, t as Input } from "./input-FeVPt8tT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/courses._id-B4h8D3ti.js
var import_jsx_runtime = require_jsx_runtime();
function CourseDetail() {
	const { id } = Route$7.useParams();
	const { data, loading, err, reload } = useRpc(() => getCourse({ data: { id } }), [id]);
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Đang tải khóa…"
	});
	if (err || !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-accent",
		children: err
	});
	async function addItem(e) {
		e.preventDefault();
		const fd = new FormData(e.currentTarget);
		const kind = String(fd.get("kind") || "VOCAB");
		let extra = "";
		if (kind === "VOCAB") extra = JSON.stringify({
			word: String(fd.get("word") || ""),
			reading: String(fd.get("reading") || ""),
			meaning: String(fd.get("meaning") || ""),
			example: String(fd.get("example") || "")
		});
		try {
			await saveCourseItem({ data: {
				courseId: id,
				kind,
				title: String(fd.get("title") || ""),
				media_url: String(fd.get("media_url") || "") || void 0,
				extra: extra || void 0
			} });
			toast.success("Đã thêm bài.");
			e.target.reset();
			reload();
		} catch (er) {
			toast.error(errorMessage(er));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Chi tiết khóa",
			title: data.title,
			desc: data.description
		}),
		data.canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ink",
				onClick: async () => {
					await setCoursePublic({ data: {
						id,
						is_public: !data.is_public
					} });
					reload();
				},
				children: data.is_public ? "Ẩn khóa" : "Công bố"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "danger",
				onClick: async () => {
					if (!confirm("Xóa khóa này?")) return;
					await deleteCourse({ data: { id } });
					window.location.assign("/courses");
				},
				children: "Xóa"
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-3",
			children: data.items.map((it) => {
				const extra = it.extra ? safeJson(it.extra) : null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "card-paper p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: it.kind
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl",
							children: it.title
						}),
						it.kind === "DRIVE" && it.media_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "text-accent underline",
							href: it.media_url,
							target: "_blank",
							rel: "noreferrer",
							children: "Mở Drive"
						}) : null,
						it.kind === "VIDEO" && it.media_url ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
							src: it.media_url,
							controls: true,
							className: "mt-2 w-full rounded-xl"
						}) : null,
						extra ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm",
							children: [
								extra.word,
								" ",
								extra.reading ? `（${extra.reading}）` : "",
								" — ",
								extra.meaning,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								extra.example
							]
						}) : null,
						data.canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							className: "mt-2",
							onClick: async () => {
								await deleteCourseItem({ data: { id: it.id } });
								reload();
							},
							children: "Xóa bài"
						}) : null
					]
				}, it.id);
			})
		}),
		data.canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: addItem,
			className: "card-paper mt-6 grid gap-3 p-5 md:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Loại bài",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
						name: "kind",
						defaultValue: "VOCAB",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "VOCAB",
								children: "Từ vựng"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "VIDEO",
								children: "Video"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "DRIVE",
								children: "Google Drive"
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Tiêu đề bài",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "title",
						required: true
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "URL video / Drive",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "media_url",
						placeholder: "https://"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Từ",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { name: "word" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Cách đọc",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { name: "reading" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nghĩa",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, { name: "meaning" })
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "md:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Ví dụ",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, { name: "example" })
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Thêm bài"
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/courses",
				className: "text-sm underline",
				children: "← Khóa học"
			})
		})
	] });
}
function safeJson(s) {
	try {
		return JSON.parse(s);
	} catch {
		return null;
	}
}
//#endregion
export { CourseDetail as component };

import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, U as require_react, x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as errorMessage, x as isPersonalEmail } from "./utils-D7h6xKRb.mjs";
import { R as saveSignupIdentity } from "./fns-BZr3NIHM.mjs";
import { t as Button } from "./button-naZWmM3u.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as authClient } from "./client-DUtYoQbQ.mjs";
import { n as useCurrentUserState } from "./use-current-user-X89NvhzM.mjs";
import { t as Field } from "./field-DNAamJBL.mjs";
import { t as Input } from "./input-FeVPt8tT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-6_3SEUui.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function nextPath() {
	if (typeof window === "undefined") return "/";
	const n = sessionStorage.getItem("nigoto_next");
	sessionStorage.removeItem("nigoto_next");
	return n && n.startsWith("/") ? n : "/";
}
function Login() {
	const nav = useNavigate();
	const { user, isPending } = useCurrentUserState();
	const [mode, setMode] = (0, import_react.useState)("in");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [fullName, setFullName] = (0, import_react.useState)("");
	const [studentId, setStudentId] = (0, import_react.useState)("");
	const [birthday, setBirthday] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!isPending && user) nav({ to: nextPath() });
	}, [
		isPending,
		user,
		nav
	]);
	async function onSubmit(e) {
		e.preventDefault();
		if (!isPersonalEmail(email)) {
			toast.error("Dùng email cá nhân hợp lệ.");
			return;
		}
		setBusy(true);
		try {
			if (mode === "in") {
				const res = await authClient.signIn.email({
					email,
					password
				});
				if (res.error) throw new Error(res.error.message || "Đăng nhập thất bại.");
			} else {
				if (password.length < 8) throw new Error("Mật khẩu tối thiểu 8 ký tự.");
				const res = await authClient.signUp.email({
					email,
					password,
					name: fullName.trim()
				});
				if (res.error) throw new Error(res.error.message || "Đăng ký thất bại.");
				await saveSignupIdentity({ data: {
					fullName,
					studentId,
					birthday
				} });
			}
			window.location.assign(nextPath());
		} catch (err) {
			toast.error(errorMessage(err));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-screen place-items-center bg-paper px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "Câu lạc bộ Nhật ngữ"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-4xl text-ink",
					children: "Nigoto Hub"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-muted",
					children: "Đăng nhập bằng email cá nhân và mật khẩu."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit,
					className: "card-paper mt-6 space-y-4 p-6",
					children: [
						mode === "up" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Họ tên",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: fullName,
									onChange: (e) => setFullName(e.target.value),
									maxLength: 30,
									required: true
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "MSSV",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: studentId,
									onChange: (e) => setStudentId(e.target.value),
									placeholder: "524H0087",
									required: true
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Ngày sinh",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "date",
									value: birthday,
									onChange: (e) => setBirthday(e.target.value),
									required: true
								})
							})
						] }) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Email cá nhân",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "email",
								value: email,
								onChange: (e) => setEmail(e.target.value),
								required: true,
								autoComplete: "email"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Mật khẩu",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "password",
								value: password,
								onChange: (e) => setPassword(e.target.value),
								required: true,
								minLength: 8,
								autoComplete: mode === "in" ? "current-password" : "new-password"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: busy || false,
							className: "w-full",
							children: busy ? "Đang xử lý…" : mode === "in" ? "Đăng nhập" : "Tạo tài khoản"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "w-full text-sm text-muted underline",
							onClick: () => setMode(mode === "in" ? "up" : "in"),
							children: mode === "in" ? "Chưa có tài khoản? Đăng ký" : "Đã có tài khoản? Đăng nhập"
						})
					]
				})
			]
		})
	});
}
//#endregion
export { Login as component };

import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { g as authMiddleware } from "./utils-D7h6xKRb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fns-BZr3NIHM.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getMe = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("7749e2977d8573d9fb42eb288dd2cd725048dc1c975e1ed42bb8cb5b26f12aa1"));
var saveSignupIdentity = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("ba552835f5b4018e5973f35aff4fd55fce5f12ad57106d30caa1fbbfdba0cec7"));
var updateMyProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("888be06492e3caf2a53a14b4e0d15d6d3a4895b82db57153dc1e15c8a8267a05"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("396c1077e338f51553edb5fc8dfe80064612657a7ca43ed80561872ab45db6b5"));
var getDashboard = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("acca3fbf74b302df3c984c5468c7a02595c98a0b51b88b96a1fe324ce9a245e4"));
var globalSearch = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("e3493cf3bd0227d7d916e606c844703896065f5c0c78d0f7611c922c31c39bb7"));
var listMembers = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("9b7da1deb93862c6dfd903580e0bff04e5ba971c523f1798a8c61a03c10cf11b"));
var getMember = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("ca7af9087eb58e7786977249d7a411a57f2bbeafc4334977ff36d70612fec9b0"));
var patchMember = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("21e2970703733646a2bf9d1c4ffaddc65f1e323df245ca72b848d1a183a12693"));
var deleteMember = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("a00e9c34ec5669e08ed40691003183cd24f7021b685fa27e2002e9b22745d993"));
var listDepartments = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("0ce251a1cf2b3a6c9fcc43fa4155cb0bef09c6962fb10f5435d445b0b45727cf"));
var getDepartment = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("f6b2a76acaa62de98d5edf783ec5306a80603bee86f0e9021a0ffffcc1e41b06"));
var assignDepartmentMember = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("1b46f8132c42db28df268b72dba3e1a05c002709bb97015794a42b9336df01d0"));
var removeDepartmentMember = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("1ece894a2011a8ed9de6dceed360021a754a38625999ecb1df99babef1b3fabe"));
var listEvents = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("530839d64b9e7f530c678a40e0cd83b68d89cb3ade688966ad9210866de07ce0"));
var getEvent = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("cc94f8b3b1332e44197e162a01cf9e290d60875cc6527b8d1deab8c3583efca6"));
var saveEvent = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("60da22b6ac526dc7fef3ea968232e29442ea495adaa693fa988f6e01e6bd9574"));
var setEventPublic = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("8ce44e30c29abf13ec656d6d24ec56f6d35828d80ab6ecc57750a130d804d3be"));
var deleteEvent = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("bc5d90460841ecbe113ae56d7405f48221c4bf854c803a7aca65b56a76a54ec2"));
var joinEvent = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("68c8ae89e7012e06fffd14560a8c1ee7d03cd173920cc7f3473960d7e90fbd38"));
var listAttendanceEvents = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("78e359e864b7d99ffa16caeae777853ded4b9097955eb680ee2b0f903c6bec18"));
var setCheckinOpen = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("5de11b3da47993a000f3823c721adf90135345f8c186a1540c62e151107b0d1a"));
var checkinEvent = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("157b1b335af15feda9cbc4ca56d07bc2987a5d23a81033a1906446909c06c572"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("9de929fc680f3f16f4c31e7b58fd76506508eb75fac99249de00d5a567184268"));
var listTasks = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("8e7a859a59a76980285b1e104f6340edaea5c57db7a5490cb6e1f5132cf3918f"));
var saveTask = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("5fcb989a01f80c5a9fdb108e3258433e2682c4511b436fa68efb17b5bcb348fd"));
var setTaskStatus = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("a3c9bb7e6c7dc8efc756c05be54dd962b9db86e58fca323e3f148e7b95ef0139"));
var deleteTask = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("22b58fa969d3f127bb3dbce25dfdf23b75f7143eadca4c97308f27010349ea0c"));
var listContent = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("3b2ca3673a2cd88d3a3f922d17e5466ab136e0f4f4ca8626140ecd3be27e05d3"));
var saveContent = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("50f873465a8c442498c9efb99627d13d3d91bdf4ca714f2209f5231c7bdf48f5"));
var reviewContent = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("d667e0be9dfbfca59ef1081de6587ce80522cd7c92e1f49ca944ec95719e8a13"));
var deleteContent = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("6cb76a1a3f29b7e93db8c4c0fd5503a2e2b8919c1791a244871d6b22ea16c0e3"));
var listCalendar = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("e2bae04c52ab91be499d941439758a6ad0eb1775131bf5b70b40dc711897e8d1"));
var listAnnouncements = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("09eef9635d1cd8dccf9e660d1a2e7bb6459d4ecac8cbcbf618062906a929e3dc"));
var saveAnnouncement = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("17a76202d45e68c9865a152c21f82cd3f32a480c764389f7f5896fe70ad9e2eb"));
var deleteAnnouncement = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("e42f6cb064f5b254f98f8397cb38a86a9e986e4841360bd7b75d884f709562af"));
var listNotifications = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("4b7c74445b8a677f03c5007fec61ada7c69581953c832b505253b8eb5664d0a9"));
var markNotificationsRead = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("1faf4fb973ae17893b2883efbf91dd4795c92133d809485a348e452d75632c2c"));
var listCourses = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("170b056adc2390ee8084f105f76b81417e1975bb19cf0bd60f2ca420138d87ce"));
var getCourse = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("eafb4c68bd9e1161d9221186ecd4a5c6cfa5dd1f3d55fa84a7a41acf6cb43776"));
var saveCourse = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("60aae911292ad73bbb4d694f85301ef435dc0140233a6d4643c4e1a3f9492ee3"));
var setCoursePublic = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("435b91bb78e7093d10cc2d797126d7683b00135145d20d3acc3c32ef7d2cee25"));
var deleteCourse = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("57656bb58956ede032de91018eb86cc8f2416928f3821937fc223d408fdab08e"));
var saveCourseItem = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("1c0b78b815515f5f0b255d4bee9ef6f1da28087fb268981622de8f6bda3d8a00"));
var deleteCourseItem = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(createSsrRpc("db71e4b3b8539ccc0640a5023d6d865387ea114f4f7f77e754a93f975f5ef51e"));
var getAnalytics = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("abc60e14b4bfb39fa0ea6273dfec4baf7482f9a9cee8fb6274406bfc2e979615"));
//#endregion
export { patchMember as A, setCheckinOpen as B, listCourses as C, listNotifications as D, listMembers as E, saveCourse as F, setEventPublic as H, saveCourseItem as I, saveEvent as L, reviewContent as M, saveAnnouncement as N, listTasks as O, saveContent as P, saveSignupIdentity as R, listContent as S, listEvents as T, setTaskStatus as U, setCoursePublic as V, updateMyProfile as W, globalSearch as _, deleteCourse as a, listAttendanceEvents as b, deleteMember as c, getCourse as d, getDashboard as f, getMember as g, getMe as h, deleteContent as i, removeDepartmentMember as j, markNotificationsRead as k, deleteTask as l, getEvent as m, checkinEvent as n, deleteCourseItem as o, getDepartment as p, deleteAnnouncement as r, deleteEvent as s, assignDepartmentMember as t, getAnalytics as u, joinEvent as v, listDepartments as w, listCalendar as x, listAnnouncements as y, saveTask as z };

import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as errorMessage, o as LIMITS } from "./utils-D7h6xKRb.mjs";
import { D as listNotifications, N as saveAnnouncement, k as markNotificationsRead, r as deleteAnnouncement, y as listAnnouncements } from "./fns-BZr3NIHM.mjs";
import { n as useRpc, t as PageHeader } from "./use-rpc-ubY9dVF8.mjs";
import { n as formatDateTime } from "./format-FEWD-XX_.mjs";
import { t as Button } from "./button-naZWmM3u.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./field-DNAamJBL.mjs";
import { r as Textarea, t as Input } from "./input-FeVPt8tT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/notifications-CmgPogQT.js
var import_jsx_runtime = require_jsx_runtime();
function Notes() {
	const board = useRpc(() => listAnnouncements());
	const box = useRpc(() => listNotifications());
	if (board.loading || box.loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Đang tải thông báo…"
	});
	async function post(e) {
		e.preventDefault();
		const fd = new FormData(e.currentTarget);
		try {
			await saveAnnouncement({ data: {
				title: String(fd.get("title") || ""),
				body: String(fd.get("body") || "")
			} });
			toast.success("Đã đăng bảng tin.");
			board.reload();
			box.reload();
			e.target.reset();
		} catch (er) {
			toast.error(errorMessage(er));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Hộp thư",
			title: "Thông báo",
			desc: "Bảng tin CLB và thư riêng.",
			action: box.data?.unread ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				onClick: async () => {
					await markNotificationsRead();
					box.reload();
				},
				children: "Đánh dấu đã đọc"
			}) : void 0
		}),
		board.data?.me.canAnnounce ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: post,
			className: "card-paper mb-6 space-y-3 p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Tiêu đề bảng tin",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "title",
						required: true,
						maxLength: LIMITS.title
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Nội dung",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						name: "body",
						required: true,
						maxLength: LIMITS.description
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Đăng bảng tin"
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "font-display text-2xl",
			children: "Bảng tin"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 space-y-3",
			children: (board.data?.rows ?? []).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "card-paper p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl break-words",
						children: a.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							a.author,
							" · ",
							formatDateTime(a.created_at)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 whitespace-pre-wrap break-words",
						children: a.body
					}),
					board.data?.me.canAnnounce ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ghost",
						className: "mt-2",
						onClick: async () => {
							await deleteAnnouncement({ data: { id: a.id } });
							board.reload();
						},
						children: "Xóa"
					}) : null
				]
			}, a.id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-8 font-display text-2xl",
			children: "Hộp thư của bạn"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-3 space-y-2",
			children: (box.data?.rows ?? []).map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: `card-paper p-4 ${n.read_at ? "" : "border-accent/40"}`,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium break-words",
						children: n.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "whitespace-pre-wrap break-words text-sm text-muted",
						children: n.body
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: formatDateTime(n.created_at)
					})
				]
			}, n.id))
		})
	] });
}
//#endregion
export { Notes as component };

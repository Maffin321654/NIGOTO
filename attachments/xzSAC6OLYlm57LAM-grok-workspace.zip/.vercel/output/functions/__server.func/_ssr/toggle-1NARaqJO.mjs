import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, U as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { v as cn } from "./utils-D7h6xKRb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/toggle-1NARaqJO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function QrBlock({ value, label }) {
	const [src, setSrc] = (0, import_react.useState)("");
	(0, import_react.useEffect)(() => {
		let live = true;
		import("../_libs/qrcode.mjs").then((n) => /* @__PURE__ */ __toESM(n.t())).then((QR) => QR.toDataURL(value, {
			width: 280,
			margin: 1,
			color: {
				dark: "#1b3a4b",
				light: "#fffdf8"
			}
		}).then((url) => {
			if (live) setSrc(url);
		}));
		return () => {
			live = false;
		};
	}, [value]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-2",
		children: [src ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src,
			alt: "Mã QR điểm danh",
			className: "h-52 w-52 rounded-2xl border border-line bg-paper-3 p-2"
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-52 w-52 rounded-2xl bg-paper-2" }), label ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}) : null]
	});
}
function Toggle({ on, onChange, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		role: "switch",
		"aria-checked": on,
		onClick: () => onChange(!on),
		className: "flex min-h-11 items-center gap-3 text-left",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("relative h-7 w-12 rounded-full transition", on ? "bg-accent" : "bg-line"),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute top-0.5 h-6 w-6 rounded-full bg-paper-3 transition", on ? "left-5.5 translate-x-0 left-[22px]" : "left-0.5") })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-sm text-ink",
			children: label
		})]
	});
}
//#endregion
export { Toggle as n, QrBlock as t };

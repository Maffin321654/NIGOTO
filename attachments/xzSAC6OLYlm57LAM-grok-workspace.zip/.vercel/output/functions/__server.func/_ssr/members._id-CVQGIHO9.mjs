import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, U as require_react, x as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as errorMessage, d as ROLE_LABEL, f as STATUSES, l as POSITION_LABEL, p as STATUS_LABEL } from "./utils-D7h6xKRb.mjs";
import { A as patchMember, c as deleteMember, g as getMember, j as removeDepartmentMember, t as assignDepartmentMember } from "./fns-BZr3NIHM.mjs";
import { n as useRpc, t as PageHeader } from "./use-rpc-ubY9dVF8.mjs";
import { t as formatDate } from "./format-FEWD-XX_.mjs";
import { t as Button } from "./button-naZWmM3u.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Route$1 } from "./router-CtBY5V57.mjs";
import { t as Field } from "./field-DNAamJBL.mjs";
import { n as Select, t as Input } from "./input-FeVPt8tT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/members._id-CVQGIHO9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MemberDetail() {
	const { id } = Route$1.useParams();
	const nav = useNavigate();
	const { data, loading, err, reload } = useRpc(() => getMember({ data: { id } }), [id]);
	const [dept, setDept] = (0, import_react.useState)("media");
	const [pos, setPos] = (0, import_react.useState)("MEMBER");
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Đang tải hồ sơ…"
	});
	if (err || !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-accent",
		children: err || "Không có dữ liệu."
	});
	async function saveIdentity(e) {
		e.preventDefault();
		const fd = new FormData(e.currentTarget);
		try {
			await patchMember({ data: {
				id,
				fullName: String(fd.get("fullName") || ""),
				studentId: String(fd.get("studentId") || ""),
				birthday: String(fd.get("birthday") || ""),
				email: String(fd.get("email") || ""),
				phone: String(fd.get("phone") || "")
			} });
			toast.success("Đã lưu hồ sơ.");
			reload();
		} catch (er) {
			toast.error(errorMessage(er));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Hồ sơ thành viên",
			title: data.full_name,
			desc: `${ROLE_LABEL[data.role]} · ${data.email}`
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-4 lg:grid-cols-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-paper space-y-2 p-5 lg:col-span-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "MSSV:"
						}),
						" ",
						data.student_id
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "Ngày sinh:"
						}),
						" ",
						data.birthday || "—"
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "SĐT:"
						}),
						" ",
						data.phone || "—"
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "Ngày vào:"
						}),
						" ",
						formatDate(data.join_date)
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "Trạng thái:"
						}),
						" ",
						STATUS_LABEL[data.status]
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "pt-2 text-sm",
						children: data.depts.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "mr-2 inline-block rounded-full bg-paper-2 px-3 py-1",
							children: [
								d.name,
								" · ",
								POSITION_LABEL[d.position]
							]
						}, d.department_id))
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-paper p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: "Điểm danh"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl tabular-nums",
						children: data.attended
					})]
				}), data.viewer.canViewStaff ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-paper p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: "Task xong"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl tabular-nums",
						children: data.tasksDone
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-paper p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: "Task đang mở"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-3xl tabular-nums",
						children: data.tasksOpen
					})]
				})] }) : null]
			})]
		}),
		data.canEdit ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: saveIdentity,
			className: "card-paper mt-6 grid gap-3 p-5 md:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl md:col-span-2",
					children: "Sửa danh tính (Chủ nhiệm)"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Họ tên",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "fullName",
						defaultValue: data.full_name,
						maxLength: 30
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "MSSV",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "studentId",
						defaultValue: data.student_id_raw ?? ""
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Ngày sinh",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "birthday",
						type: "date",
						defaultValue: data.birthday ?? ""
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Email đăng nhập",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "email",
						type: "email",
						defaultValue: data.email
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "SĐT",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "phone",
						defaultValue: data.phone ?? ""
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "md:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Lưu thay đổi"
					})
				})
			]
		}) : null,
		data.canManage ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card-paper mt-6 space-y-4 p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl",
					children: "Phân ban"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: dept,
							onChange: (e) => setDept(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "bcn",
									children: "Ban Chủ nhiệm"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "members",
									children: "Ban Thành viên"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "media",
									children: "Ban Truyền thông"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "academic",
									children: "Ban Học thuật"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "event",
									children: "Ban Sự kiện"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: pos,
							onChange: (e) => setPos(e.target.value),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "HEAD",
									children: "Trưởng ban"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "VICE_HEAD",
									children: "Phó ban"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "MEMBER",
									children: "Thành viên"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: async () => {
								try {
									await assignDepartmentMember({ data: {
										departmentId: dept,
										userId: id,
										position: pos
									} });
									toast.success("Đã phân ban.");
									reload();
								} catch (e) {
									toast.error(errorMessage(e));
								}
							},
							children: "Thêm / đổi chức"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-2",
					children: data.depts.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						onClick: async () => {
							await removeDepartmentMember({ data: {
								departmentId: d.department_id,
								userId: id
							} });
							reload();
						},
						children: ["Gỡ ", d.name]
					}, d.department_id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							defaultValue: data.role,
							onChange: async (e) => {
								await patchMember({ data: {
									id,
									role: e.target.value
								} });
								reload();
							},
							children: Object.entries(ROLE_LABEL).map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: k,
								children: v
							}, k))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
							defaultValue: data.status,
							onChange: async (e) => {
								await patchMember({ data: {
									id,
									status: e.target.value
								} });
								reload();
							},
							children: STATUSES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: s,
								children: STATUS_LABEL[s]
							}, s))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "danger",
							onClick: async () => {
								if (!confirm("Xóa tài khoản này? Email sẽ đăng ký lại được.")) return;
								try {
									await deleteMember({ data: { id } });
									toast.success("Đã xóa.");
									nav({ to: "/members" });
								} catch (e) {
									toast.error(errorMessage(e));
								}
							},
							children: "Xóa tài khoản"
						})
					]
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/members",
				className: "text-sm underline",
				children: "← Danh sách thành viên"
			})
		})
	] });
}
//#endregion
export { MemberDetail as component };

import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, U as require_react, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as errorMessage, l as POSITION_LABEL } from "./utils-D7h6xKRb.mjs";
import { E as listMembers, j as removeDepartmentMember, p as getDepartment, t as assignDepartmentMember } from "./fns-BZr3NIHM.mjs";
import { n as useRpc, t as PageHeader } from "./use-rpc-ubY9dVF8.mjs";
import { t as Button } from "./button-naZWmM3u.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as Route$5 } from "./router-CtBY5V57.mjs";
import { n as Select } from "./input-FeVPt8tT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/departments._id-_igpQQvi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DeptDetail() {
	const { id } = Route$5.useParams();
	const { data, loading, err, reload } = useRpc(() => getDepartment({ data: { id } }), [id]);
	const people = useRpc(() => listMembers());
	const [uid, setUid] = (0, import_react.useState)("");
	const [pos, setPos] = (0, import_react.useState)("MEMBER");
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Đang tải ban…"
	});
	if (err || !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-accent",
		children: err
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Chi tiết ban",
			title: data.name,
			desc: data.description
		}),
		data.canManage ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "card-paper mb-4 flex flex-wrap gap-2 p-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: uid,
					onChange: (e) => setUid(e.target.value),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: "",
						children: "Chọn thành viên…"
					}), (people.data ?? []).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: p.user_id,
						children: p.full_name
					}, p.user_id))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
					value: pos,
					onChange: (e) => setPos(e.target.value),
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "HEAD",
							children: "Trưởng ban"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "VICE_HEAD",
							children: "Phó ban"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: "MEMBER",
							children: "Thành viên"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					onClick: async () => {
						if (!uid) return;
						try {
							await assignDepartmentMember({ data: {
								departmentId: id,
								userId: uid,
								position: pos
							} });
							toast.success("Đã thêm vào ban.");
							reload();
						} catch (e) {
							toast.error(errorMessage(e));
						}
					},
					children: "Thêm vào ban"
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "card-paper divide-y divide-line",
			children: data.members.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2 px-5 py-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/members/$id",
					params: { id: m.user_id },
					className: "font-medium hover:underline",
					children: [
						m.full_name,
						" · ",
						POSITION_LABEL[m.position],
						" · ",
						m.student_id
					]
				}), data.canManage ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "ghost",
					onClick: async () => {
						await removeDepartmentMember({ data: {
							departmentId: id,
							userId: m.user_id
						} });
						reload();
					},
					children: "Gỡ khỏi ban"
				}) : null]
			}, m.user_id))
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-4",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/departments",
				className: "text-sm underline",
				children: "← Các ban"
			})
		})
	] });
}
//#endregion
export { DeptDetail as component };

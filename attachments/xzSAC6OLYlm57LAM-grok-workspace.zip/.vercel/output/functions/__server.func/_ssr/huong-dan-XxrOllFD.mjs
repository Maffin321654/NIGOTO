import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as getMe } from "./fns-BZr3NIHM.mjs";
import { n as useRpc, t as PageHeader } from "./use-rpc-ubY9dVF8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/huong-dan-XxrOllFD.js
var import_jsx_runtime = require_jsx_runtime();
var BLOCKS = [
	{
		id: "members",
		title: "Thành viên",
		body: "Xem sự kiện đã công bố, khóa học public, bảng tin, điểm danh bằng cách quét QR do ban quản trị đưa. Không thấy Công việc / Media / Lịch / Thống kê cho đến khi được phân ban."
	},
	{
		id: "media",
		title: "Ban Truyền thông",
		body: "Tạo content trong Media Center, bắt buộc chọn ngày giờ đăng (lịch), gửi duyệt, đăng bảng tin, xem QR điểm danh."
	},
	{
		id: "academic",
		title: "Ban Học thuật",
		body: "Tạo khóa học (video ≤8MB, từ vựng, Drive), công bố khi sẵn sàng. Xem QR điểm danh."
	},
	{
		id: "event",
		title: "Ban Sự kiện",
		body: "Tạo / xóa sự kiện, xem sự kiện chưa công bố, bật tắt nhận điểm danh, mã QR."
	},
	{
		id: "bcn",
		title: "Ban Chủ nhiệm",
		body: "Phân ban, đổi quyền, xóa thành viên, tạo task, công bố sự kiện/khóa học, xem mọi trang."
	},
	{
		id: "president",
		title: "Chủ nhiệm",
		body: "Chỉ Chủ nhiệm được đổi họ tên, MSSV, ngày sinh và email đăng nhập của người khác."
	}
];
function Guide() {
	const { data, loading } = useRpc(() => getMe());
	if (loading || !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Đang tải hướng dẫn…"
	});
	const ids = /* @__PURE__ */ new Set(["members"]);
	if (data.inMedia) ids.add("media");
	if (data.inAcademic) ids.add("academic");
	if (data.inEvent) ids.add("event");
	if (data.inBcn || data.isAdmin) {
		ids.add("bcn");
		ids.add("media");
		ids.add("academic");
		ids.add("event");
	}
	if (data.isPresident || data.canEditIdentity) ids.add("president");
	const shown = BLOCKS.filter((b) => ids.has(b.id));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		kicker: "Cẩm nang",
		title: "Hướng dẫn",
		desc: "Theo ban bạn đang ở."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: shown.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: "card-paper p-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: b.title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-muted",
				children: b.body
			})]
		}, b.id))
	})] });
}
//#endregion
export { Guide as component };

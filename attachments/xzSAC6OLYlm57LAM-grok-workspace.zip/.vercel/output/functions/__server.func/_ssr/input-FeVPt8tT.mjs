import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { v as cn } from "./utils-D7h6xKRb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/input-FeVPt8tT.js
var import_jsx_runtime = require_jsx_runtime();
var field = "w-full rounded-xl border border-line bg-paper-3 px-3 py-2.5 text-ink outline-none focus:border-ink min-h-11";
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn(field, className),
		...props
	});
}
function Textarea({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn(field, "min-h-28 resize-y", className),
		...props
	});
}
function Select({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		className: cn(field, className),
		...props
	});
}
//#endregion
export { Select as n, Textarea as r, Input as t };

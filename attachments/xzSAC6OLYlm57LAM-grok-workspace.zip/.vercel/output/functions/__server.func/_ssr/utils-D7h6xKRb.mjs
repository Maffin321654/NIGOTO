import { n as createMiddleware } from "./ssr.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-D7h6xKRb.js
/**
* Auth middleware for server functions — the standard way to get the caller's
* verified user id. When deployed the session cookie is same-origin and rides
* along automatically. In the live preview the client also forwards the bearer
* token (partitioned cookies) via the `.client` hook below — call sites do not
* thread it themselves.
*
*   import { createServerFn } from "@tanstack/react-start";
*   import { getSql } from "@/lib/db";
*   import { authMiddleware } from "@/lib/auth/middleware";
*
*   export const listTodos = createServerFn({ method: "GET" })
*     .middleware([authMiddleware])
*     .handler(async ({ context }) => {
*       const sql = await getSql();
*       return sql`select * from todos where user_id = ${context.userId}`;
*     });
*
* Signed out with auth on (live preview included) -> throws `UnauthorizedError`
* (see `verify.server.ts`). With auth disabled (`VITE_AUTH_ENABLED=false`, the
* shipped default) it resolves the shared dev user — but throws instead when a
* `DATABASE_URL` is also set, so an app without sign-in must not use this at
* all. On the auth-on path, use it on every server function that touches
* per-user data and scope every query by `context.userId`.
*/
var authMiddleware = createMiddleware({ type: "function" }).client(async ({ next }) => {
	const { getBearerToken } = await import("./client-DUtYoQbQ.mjs").then((n) => n.n);
	return next({ sendContext: { bearerToken: getBearerToken() ?? void 0 } });
}).server(async ({ next, context }) => {
	const { assertSameSiteRequest } = await import("./isolation.server-CGNg1r0B.mjs");
	const { requireUserId } = await import("./verify.server-BMNBAIB4.mjs");
	assertSameSiteRequest();
	return next({ context: { userId: await requireUserId(context.bearerToken) } });
});
var ROLES = {
	SUPER_ADMIN: "SUPER_ADMIN",
	PRESIDENT: "PRESIDENT",
	VICE_PRESIDENT: "VICE_PRESIDENT",
	MEMBER: "MEMBER"
};
var ROLE_LABEL = {
	SUPER_ADMIN: "Super Admin",
	PRESIDENT: "Chủ nhiệm",
	VICE_PRESIDENT: "Phó chủ nhiệm",
	MEMBER: "Thành viên"
};
var STATUSES = [
	"ACTIVE",
	"PENDING",
	"INACTIVE",
	"ALUMNI"
];
var STATUS_LABEL = {
	ACTIVE: "Đang hoạt động",
	PENDING: "Chờ duyệt",
	INACTIVE: "Tạm nghỉ",
	ALUMNI: "Cựu thành viên"
};
var POSITIONS = [
	"HEAD",
	"VICE_HEAD",
	"MEMBER"
];
var POSITION_LABEL = {
	HEAD: "Trưởng ban",
	VICE_HEAD: "Phó ban",
	MEMBER: "Thành viên"
};
var DEPT_SEED = [
	{
		id: "bcn",
		name: "Ban Chủ nhiệm",
		description: "Điều hành nhân sự, công việc và công bố hoạt động.",
		sort: 0
	},
	{
		id: "members",
		name: "Ban Thành viên",
		description: "Nơi thành viên mới trước khi được phân ban chuyên môn.",
		sort: 1
	},
	{
		id: "media",
		name: "Ban Truyền thông",
		description: "Nội dung, poster, bảng tin và lịch đăng bài.",
		sort: 2
	},
	{
		id: "academic",
		name: "Ban Học thuật",
		description: "Khóa học tiếng Nhật, từ vựng và tài liệu.",
		sort: 3
	},
	{
		id: "event",
		name: "Ban Sự kiện",
		description: "Tổ chức sự kiện, điểm danh và hậu cần.",
		sort: 4
	}
];
var EVENT_TYPES = [
	{
		id: "CULTURE",
		label: "Văn hóa"
	},
	{
		id: "WORKSHOP",
		label: "Workshop"
	},
	{
		id: "EXCHANGE",
		label: "Giao lưu"
	},
	{
		id: "CLASS",
		label: "Lớp học"
	},
	{
		id: "CONTEST",
		label: "Cuộc thi"
	},
	{
		id: "TEAM",
		label: "Team building"
	},
	{
		id: "RECRUIT",
		label: "Tuyển thành viên"
	},
	{
		id: "INTERNAL",
		label: "Nội bộ"
	}
];
var EVENT_STATUS = [
	{
		id: "DRAFT",
		label: "Nháp"
	},
	{
		id: "UPCOMING",
		label: "Sắp diễn ra"
	},
	{
		id: "ONGOING",
		label: "Đang diễn ra"
	},
	{
		id: "COMPLETED",
		label: "Đã xong"
	},
	{
		id: "CANCELLED",
		label: "Hủy"
	}
];
var TASK_STATUS = [
	{
		id: "TODO",
		label: "Cần làm"
	},
	{
		id: "IN_PROGRESS",
		label: "Đang làm"
	},
	{
		id: "REVIEW",
		label: "Chờ duyệt"
	},
	{
		id: "COMPLETED",
		label: "Hoàn thành"
	}
];
var TASK_PRIORITY = [
	{
		id: "LOW",
		label: "Thấp"
	},
	{
		id: "MEDIUM",
		label: "Trung bình"
	},
	{
		id: "HIGH",
		label: "Cao"
	},
	{
		id: "URGENT",
		label: "Khẩn"
	}
];
var CONTENT_STATUS = [
	{
		id: "IDEA",
		label: "Ý tưởng"
	},
	{
		id: "SUBMITTED",
		label: "Chờ duyệt"
	},
	{
		id: "APPROVED",
		label: "Đã duyệt"
	},
	{
		id: "REJECTED",
		label: "Từ chối"
	},
	{
		id: "CHANGES",
		label: "Yêu cầu sửa"
	},
	{
		id: "SCHEDULED",
		label: "Lên lịch"
	},
	{
		id: "PUBLISHED",
		label: "Đã đăng"
	}
];
var PLATFORMS = [
	{
		id: "FACEBOOK",
		label: "Facebook"
	},
	{
		id: "INSTAGRAM",
		label: "Instagram"
	},
	{
		id: "TIKTOK",
		label: "TikTok"
	},
	{
		id: "OTHER",
		label: "Khác"
	}
];
var CONTENT_TYPES = [
	{
		id: "POSTER",
		label: "Poster"
	},
	{
		id: "CAPTION",
		label: "Caption"
	},
	{
		id: "VIDEO",
		label: "Video"
	},
	{
		id: "REEL",
		label: "Reel"
	},
	{
		id: "STORY",
		label: "Story"
	},
	{
		id: "RECAP",
		label: "Recap"
	},
	{
		id: "RECRUIT",
		label: "Tuyển quân"
	},
	{
		id: "ANNOUNCE",
		label: "Thông báo"
	},
	{
		id: "EDU",
		label: "Học thuật"
	}
];
var LIMITS = {
	name: 30,
	studentId: 10,
	phone: 12,
	title: 100,
	description: 2e3,
	videoBytes: 8388608
};
function labelOf(list, id) {
	return list.find((x) => x.id === id)?.label ?? id;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function nid(prefix = "id") {
	return `${prefix}-${Math.random().toString(36).slice(2, 10)}${Date.now().toString(36).slice(-4)}`;
}
function clip(s, max) {
	return s.trim().slice(0, max);
}
function errorMessage(err, fallback = "Có lỗi xảy ra") {
	if (err instanceof Error && err.message) return err.message;
	if (typeof err === "string" && err) return err;
	if (err && typeof err === "object" && "message" in err) {
		const m = err.message;
		if (typeof m === "string" && m) return m;
	}
	return fallback;
}
function toLocalInput(iso) {
	if (!iso) return "";
	const d = typeof iso === "string" ? new Date(iso) : iso;
	if (Number.isNaN(d.getTime())) return "";
	const pad = (n) => String(n).padStart(2, "0");
	return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function validateName(name) {
	const v = name.trim();
	if (!v) throw new Error("Họ tên bắt buộc.");
	if (v.length > LIMITS.name) throw new Error(`Họ tên tối đa ${LIMITS.name} ký tự.`);
	return v;
}
function validateStudentId(raw) {
	const v = raw.trim().toUpperCase();
	if (v.length < 4 || v.length > LIMITS.studentId) throw new Error("MSSV gồm 4–10 ký tự (ví dụ 524H0087).");
	if (!/^[A-Z0-9]+$/.test(v)) throw new Error("MSSV chỉ gồm chữ và số.");
	const letters = (v.match(/[A-Z]/g) ?? []).length;
	if ((v.match(/[0-9]/g) ?? []).length < 1) throw new Error("MSSV phải có ít nhất 1 chữ số.");
	if (letters > 2) throw new Error("MSSV tối đa 2 chữ cái.");
	return v;
}
function maskStudentId(id) {
	if (!id) return "—";
	if (id.length <= 4) return id;
	return `${id.slice(0, 2)}${"*".repeat(Math.max(2, id.length - 4))}${id.slice(-2)}`;
}
function validatePhone(raw) {
	const v = raw.replace(/\s+/g, "");
	if (!v) return "";
	if (!/^\d+$/.test(v)) throw new Error("Số điện thoại chỉ gồm chữ số.");
	if (v.length > LIMITS.phone) throw new Error(`Số điện thoại tối đa ${LIMITS.phone} số.`);
	return v;
}
function validateBirthday(raw) {
	const v = raw.trim();
	if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) throw new Error("Ngày sinh không hợp lệ.");
	const d = /* @__PURE__ */ new Date(`${v}T00:00:00`);
	if (Number.isNaN(d.getTime())) throw new Error("Ngày sinh không hợp lệ.");
	const year = d.getFullYear();
	if (year < 1950) throw new Error("Năm sinh không hợp lệ.");
	const today = /* @__PURE__ */ new Date();
	if (d > today) throw new Error("Ngày sinh không được ở tương lai.");
	if (today.getFullYear() - year - (today.getMonth() < d.getMonth() || today.getMonth() === d.getMonth() && today.getDate() < d.getDate() ? 1 : 0) < 10) throw new Error("Thành viên phải từ 10 tuổi trở lên.");
	return v;
}
function validateTitle(raw) {
	const v = clip(raw, LIMITS.title);
	if (!v) throw new Error("Tiêu đề bắt buộc.");
	return v;
}
function validateDesc(raw) {
	return clip(raw, LIMITS.description);
}
function isPersonalEmail(email) {
	return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim().toLowerCase());
}
function compressImage(file, max = 900, quality = .72) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		const url = URL.createObjectURL(file);
		img.onload = () => {
			const scale = Math.min(1, max / Math.max(img.width, img.height));
			const canvas = document.createElement("canvas");
			canvas.width = Math.round(img.width * scale);
			canvas.height = Math.round(img.height * scale);
			const ctx = canvas.getContext("2d");
			if (!ctx) {
				URL.revokeObjectURL(url);
				reject(/* @__PURE__ */ new Error("Không nén được ảnh."));
				return;
			}
			ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
			URL.revokeObjectURL(url);
			resolve(canvas.toDataURL("image/jpeg", quality));
		};
		img.onerror = () => {
			URL.revokeObjectURL(url);
			reject(/* @__PURE__ */ new Error("Không đọc được ảnh."));
		};
		img.src = url;
	});
}
//#endregion
export { validateStudentId as A, maskStudentId as C, validateDesc as D, validateBirthday as E, validateName as O, labelOf as S, toLocalInput as T, clip as _, EVENT_TYPES as a, errorMessage as b, POSITIONS as c, ROLE_LABEL as d, STATUSES as f, authMiddleware as g, TASK_STATUS as h, EVENT_STATUS as i, validateTitle as j, validatePhone as k, POSITION_LABEL as l, TASK_PRIORITY as m, CONTENT_TYPES as n, LIMITS as o, STATUS_LABEL as p, DEPT_SEED as r, PLATFORMS as s, CONTENT_STATUS as t, ROLES as u, cn as v, nid as w, isPersonalEmail as x, compressImage as y };

import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, U as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as errorMessage } from "./utils-D7h6xKRb.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-rpc-ubY9dVF8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PageHeader({ kicker, title, desc, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-6 flex flex-wrap items-end justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 font-display text-4xl tracking-tight text-ink",
				children: title
			}),
			desc ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-muted",
				children: desc
			}) : null
		] }), action]
	});
}
function useRpc(fn, deps = []) {
	const [data, setData] = (0, import_react.useState)(null);
	const [err, setErr] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(true);
	const reload = (0, import_react.useCallback)(() => {
		let live = true;
		setLoading(true);
		setErr(null);
		fn().then((v) => {
			if (live) setData(v);
		}).catch((e) => {
			if (live) setErr(errorMessage(e));
		}).finally(() => {
			if (live) setLoading(false);
		});
		return () => {
			live = false;
		};
	}, deps);
	(0, import_react.useEffect)(() => {
		return reload();
	}, [reload]);
	return {
		data,
		err,
		loading,
		reload,
		setData
	};
}
//#endregion
export { useRpc as n, PageHeader as t };

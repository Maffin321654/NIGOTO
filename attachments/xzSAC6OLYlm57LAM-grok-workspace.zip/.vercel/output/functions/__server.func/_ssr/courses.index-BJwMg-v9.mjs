import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, U as require_react, x as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as errorMessage, o as LIMITS } from "./utils-D7h6xKRb.mjs";
import { C as listCourses, F as saveCourse } from "./fns-BZr3NIHM.mjs";
import { n as useRpc, t as PageHeader } from "./use-rpc-ubY9dVF8.mjs";
import { t as Button } from "./button-naZWmM3u.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./field-DNAamJBL.mjs";
import { r as Textarea, t as Input } from "./input-FeVPt8tT.mjs";
import { t as EmptyState } from "./empty-state-B_Ow87ZB.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/courses.index-BJwMg-v9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Courses() {
	const { data, loading, err, reload } = useRpc(() => listCourses());
	const nav = useNavigate();
	const [open, setOpen] = (0, import_react.useState)(false);
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Đang tải khóa học…"
	});
	if (err) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-accent",
		children: err
	});
	const can = data?.me.canCreateCourse;
	async function onCreate(e) {
		e.preventDefault();
		const fd = new FormData(e.currentTarget);
		try {
			const r = await saveCourse({ data: {
				title: String(fd.get("title") || ""),
				description: String(fd.get("description") || "")
			} });
			toast.success("Đã tạo khóa (chưa công bố).");
			setOpen(false);
			reload();
			await nav({
				to: "/courses/$id",
				params: { id: r.id }
			});
		} catch (er) {
			toast.error(errorMessage(er));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Học thuật",
			title: "Khóa học",
			desc: "Video, từ vựng, Drive. Bấm một khóa để xem bài học.",
			action: can ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setOpen((v) => !v),
				children: open ? "Đóng form" : "Tạo khóa"
			}) : void 0
		}),
		open && can ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: onCreate,
			className: "card-paper mb-6 space-y-3 p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Tên khóa",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "title",
						required: true,
						maxLength: LIMITS.title
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Mô tả",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						name: "description",
						maxLength: LIMITS.description
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Lưu"
				})
			]
		}) : null,
		(data?.rows.length ?? 0) === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyState, { title: "Chưa có khóa công bố" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 md:grid-cols-2",
			children: data.rows.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/courses/$id",
				params: { id: c.id },
				className: "card-paper block p-5 hover:border-ink/30",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl break-words",
						children: c.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 line-clamp-3 text-sm text-muted",
						children: c.description
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs",
						children: c.is_public ? "Công khai" : "Nháp"
					})
				]
			}, c.id))
		})
	] });
}
//#endregion
export { Courses as component };

import { o as __toESM } from "../_runtime.mjs";
import { C as require_jsx_runtime, U as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { S as labelOf, b as errorMessage, h as TASK_STATUS, m as TASK_PRIORITY, o as LIMITS } from "./utils-D7h6xKRb.mjs";
import { E as listMembers, O as listTasks, U as setTaskStatus, l as deleteTask, z as saveTask } from "./fns-BZr3NIHM.mjs";
import { n as useRpc, t as PageHeader } from "./use-rpc-ubY9dVF8.mjs";
import { t as formatDate } from "./format-FEWD-XX_.mjs";
import { t as Button } from "./button-naZWmM3u.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./field-DNAamJBL.mjs";
import { n as Select, r as Textarea, t as Input } from "./input-FeVPt8tT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tasks-DXE9uk1E.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Tasks() {
	const { data, loading, err, reload } = useRpc(() => listTasks());
	const people = useRpc(() => listMembers());
	const [open, setOpen] = (0, import_react.useState)(false);
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Đang tải việc…"
	});
	if (err) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-accent",
		children: err
	});
	const can = data?.me.canCreateTask;
	const cols = TASK_STATUS;
	async function onCreate(e) {
		e.preventDefault();
		const fd = new FormData(e.currentTarget);
		const assigneeIds = fd.getAll("assignees").map(String).filter(Boolean);
		try {
			await saveTask({ data: {
				title: String(fd.get("title") || ""),
				description: String(fd.get("description") || ""),
				status: "TODO",
				priority: String(fd.get("priority") || "MEDIUM"),
				deadline: fd.get("deadline") ? new Date(String(fd.get("deadline"))).toISOString() : void 0,
				assigneeIds
			} });
			toast.success("Đã giao việc.");
			setOpen(false);
			reload();
		} catch (er) {
			toast.error(errorMessage(er));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Kanban",
			title: "Công việc",
			desc: "Kéo trạng thái bằng nút. Dashboard cũng có xác nhận đang làm / hoàn thành.",
			action: can ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				onClick: () => setOpen((v) => !v),
				children: "Tạo việc"
			}) : void 0
		}),
		open && can ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit: onCreate,
			className: "card-paper mb-6 grid gap-3 p-5 md:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Tiêu đề",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "title",
						required: true,
						maxLength: LIMITS.title
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Ưu tiên",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Select, {
						name: "priority",
						children: TASK_PRIORITY.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: p.id,
							children: p.label
						}, p.id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Hạn",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "deadline",
						type: "datetime-local"
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Giao cho",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						name: "assignees",
						multiple: true,
						className: "min-h-28 w-full rounded-xl border border-line bg-paper-3 p-2",
						children: (people.data ?? []).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
							value: p.user_id,
							children: p.full_name
						}, p.user_id))
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "md:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Mô tả",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							name: "description",
							maxLength: LIMITS.description
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "md:col-span-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Lưu"
					})
				})
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-3 md:grid-cols-4",
			children: cols.map((col) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-paper p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker px-1 py-2",
					children: col.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "space-y-2",
					children: (data?.tasks ?? []).filter((t) => t.status === col.id).map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-line bg-paper p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium break-words",
								children: t.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: [
									labelOf(TASK_PRIORITY, t.priority),
									" ",
									t.deadline ? `· ${formatDate(t.deadline)}` : "",
									" ",
									t.overdue ? "· Quá hạn" : ""
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: t.assignees.map((a) => a.full_name).join(", ")
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex flex-wrap gap-1",
								children: [cols.filter((c) => c.id !== t.status).map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "rounded-full bg-paper-3 px-2 py-1 text-[11px]",
									onClick: async () => {
										await setTaskStatus({ data: {
											id: t.id,
											status: c.id
										} });
										reload();
									},
									children: c.label
								}, c.id)), can ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									className: "rounded-full px-2 py-1 text-[11px] text-accent",
									onClick: async () => {
										if (!confirm("Xóa việc này?")) return;
										await deleteTask({ data: { id: t.id } });
										reload();
									},
									children: "Xóa"
								}) : null]
							})
						]
					}, t.id))
				})]
			}, col.id))
		})
	] });
}
//#endregion
export { Tasks as component };

import { C as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { w as listDepartments } from "./fns-BZr3NIHM.mjs";
import { n as useRpc, t as PageHeader } from "./use-rpc-ubY9dVF8.mjs";
import { a as ChevronRight } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/departments.index-BAVap_Z6.js
var import_jsx_runtime = require_jsx_runtime();
function Depts() {
	const { data, loading, err } = useRpc(() => listDepartments());
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Đang tải…"
	});
	if (err) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-accent",
		children: err
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		kicker: "Cơ cấu",
		title: "Các ban",
		desc: "Bấm vào một ban để xem thành viên và phân quyền."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-3 md:grid-cols-2",
		children: (data ?? []).map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/departments/$id",
			params: { id: d.id },
			className: "card-paper flex items-start justify-between gap-3 p-5 hover:border-ink/30",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl",
					children: d.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: d.description
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 tabular-nums text-accent",
					children: [d.n, " thành viên"]
				})
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "mt-2 size-5 shrink-0 text-muted" })]
		}, d.id))
	})] });
}
//#endregion
export { Depts as component };

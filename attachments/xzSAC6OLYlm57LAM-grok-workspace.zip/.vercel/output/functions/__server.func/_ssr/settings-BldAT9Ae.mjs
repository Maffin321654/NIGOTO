import { C as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as errorMessage, d as ROLE_LABEL, l as POSITION_LABEL } from "./utils-D7h6xKRb.mjs";
import { W as updateMyProfile, h as getMe } from "./fns-BZr3NIHM.mjs";
import { n as useRpc, t as PageHeader } from "./use-rpc-ubY9dVF8.mjs";
import { t as Button } from "./button-naZWmM3u.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as Field } from "./field-DNAamJBL.mjs";
import { t as Input } from "./input-FeVPt8tT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-BldAT9Ae.js
var import_jsx_runtime = require_jsx_runtime();
function Settings() {
	const { data, loading, err, reload } = useRpc(() => getMe());
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Đang tải hồ sơ…"
	});
	if (err || !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-accent",
		children: err
	});
	async function save(e) {
		e.preventDefault();
		const fd = new FormData(e.currentTarget);
		try {
			await updateMyProfile({ data: { phone: String(fd.get("phone") || "") } });
			toast.success("Đã lưu số điện thoại.");
			reload();
		} catch (er) {
			toast.error(errorMessage(er));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		kicker: "Tài khoản",
		title: "Hồ sơ",
		desc: "Họ tên, MSSV và ngày sinh do Chủ nhiệm chỉnh nếu sai."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card-paper max-w-xl space-y-3 p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: "Họ tên:"
				}),
				" ",
				data.name
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: "Email:"
				}),
				" ",
				data.email
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: "MSSV:"
				}),
				" ",
				data.studentId || "—"
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: "Ngày sinh:"
				}),
				" ",
				data.birthday || "—"
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: "Vai trò:"
				}),
				" ",
				ROLE_LABEL[data.role]
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-muted",
					children: "Ban:"
				}),
				" ",
				data.depts.map((d) => `${d.name} (${POSITION_LABEL[d.position]})`).join(", ") || "—"
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: save,
				className: "space-y-3 pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Số điện thoại (chỉ số, tối đa 12)",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						name: "phone",
						defaultValue: data.phone ?? "",
						inputMode: "numeric",
						maxLength: 12
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					children: "Lưu hồ sơ"
				})]
			})
		]
	})] });
}
//#endregion
export { Settings as component };

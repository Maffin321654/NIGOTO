import { C as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { B as setCheckinOpen, b as listAttendanceEvents } from "./fns-BZr3NIHM.mjs";
import { n as useRpc, t as PageHeader } from "./use-rpc-ubY9dVF8.mjs";
import { n as formatDateTime } from "./format-FEWD-XX_.mjs";
import { n as Toggle, t as QrBlock } from "./toggle-1NARaqJO.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/attendance-BhONU5hj.js
var import_jsx_runtime = require_jsx_runtime();
function Attendance() {
	const { data, loading, err, reload } = useRpc(() => listAttendanceEvents());
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Đang tải điểm danh…"
	});
	if (err || !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-accent",
		children: err
	});
	const staff = data.me.canToggleCheckin;
	const origin = typeof window !== "undefined" ? window.location.origin : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		kicker: "Check-in",
		title: "Điểm danh",
		desc: staff ? "QR chỉ hiện với ban quản trị. Bật/tắt nhận điểm danh từng sự kiện." : "Quét mã QR do ban quản trị đưa. Sau khi quét bạn sẽ thấy Đã điểm danh."
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-4",
		children: data.events.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("article", {
			className: "card-paper p-5",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/events/$id",
						params: { id: e.id },
						className: "font-display text-2xl hover:underline",
						children: e.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							formatDateTime(e.start_at),
							" · ",
							e.location || "—"
						]
					}),
					staff ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm",
						children: ["Đã điểm danh: ", e.attended_count]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-medium",
						children: e.attended ? "Đã điểm danh" : "Quét mã QR do ban quản trị"
					})
				] }), staff ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-end gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toggle, {
						on: e.checkin_open,
						onChange: async (v) => {
							await setCheckinOpen({ data: {
								id: e.id,
								open: v
							} });
							reload();
						},
						label: e.checkin_open ? "Nhận thêm điểm danh" : "Không nhận thêm"
					}), origin ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrBlock, { value: `${origin}/checkin/${e.id}` }) : null]
				}) : null]
			})
		}, e.id))
	})] });
}
//#endregion
export { Attendance as component };

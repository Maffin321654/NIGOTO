import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { A as validateStudentId, C as maskStudentId, D as validateDesc, E as validateBirthday, O as validateName, _ as clip, c as POSITIONS, f as STATUSES, g as authMiddleware, j as validateTitle, k as validatePhone, o as LIMITS, r as DEPT_SEED, u as ROLES, w as nid } from "./utils-D7h6xKRb.mjs";
import { r as getSql } from "./db-jydF0jkP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fns-DPwuK0iF.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var IDENT = /^[a-z_][a-z0-9_]*$/i;
var HEAL_TABLES = [
	"departments",
	"profiles",
	"department_members",
	"events",
	"event_departments",
	"event_participants",
	"attendance",
	"tasks",
	"task_assignees",
	"task_comments",
	"content_items",
	"content_approvals",
	"announcements",
	"notifications",
	"courses",
	"course_items",
	"activity_logs",
	"club_state"
];
var ADD_COLUMNS = [
	["departments", "sort_order int not null default 0"],
	["departments", "description text not null default ''"],
	["departments", "slug text not null default ''"],
	["departments", "color text not null default ''"],
	["departments", "icon text not null default ''"],
	["departments", "created_at timestamptz not null default now()"],
	["departments", "updated_at timestamptz not null default now()"],
	["profiles", "full_name text not null default ''"],
	["profiles", "student_id text"],
	["profiles", "phone text"],
	["profiles", "birthday date"],
	["profiles", "role text not null default 'MEMBER'"],
	["profiles", "status text not null default 'ACTIVE'"],
	["profiles", "join_date timestamptz not null default now()"],
	["profiles", "avatar_url text"],
	["profiles", "deleted_at timestamptz"],
	["profiles", "email text not null default ''"],
	["profiles", "slug text not null default ''"],
	["department_members", "position text not null default 'MEMBER'"],
	["department_members", "joined_at timestamptz not null default now()"],
	["events", "title text not null default ''"],
	["events", "description text not null default ''"],
	["events", "event_type text not null default 'CULTURE'"],
	["events", "status text not null default 'UPCOMING'"],
	["events", "location text not null default ''"],
	["events", "start_at timestamptz not null default now()"],
	["events", "end_at timestamptz"],
	["events", "max_participants int"],
	["events", "cover_url text"],
	["events", "is_public boolean not null default false"],
	["events", "checkin_open boolean not null default true"],
	["events", "checkin_token text not null default ''"],
	["events", "organizer_id text not null default ''"],
	["events", "created_at timestamptz not null default now()"],
	["events", "updated_at timestamptz not null default now()"],
	["events", "deleted_at timestamptz"],
	["events", "slug text not null default ''"],
	["event_participants", "joined_at timestamptz not null default now()"],
	["attendance", "checked_at timestamptz not null default now()"],
	["attendance", "method text not null default 'QR'"],
	["attendance", "event_id text"],
	["attendance", "user_id text"],
	["tasks", "title text not null default ''"],
	["tasks", "description text not null default ''"],
	["tasks", "status text not null default 'TODO'"],
	["tasks", "priority text not null default 'MEDIUM'"],
	["tasks", "deadline timestamptz"],
	["tasks", "creator_id text not null default ''"],
	["tasks", "department_id text"],
	["tasks", "event_id text"],
	["tasks", "created_at timestamptz not null default now()"],
	["tasks", "updated_at timestamptz not null default now()"],
	["tasks", "deleted_at timestamptz"],
	["task_comments", "body text not null default ''"],
	["task_comments", "created_at timestamptz not null default now()"],
	["content_items", "title text not null default ''"],
	["content_items", "caption text not null default ''"],
	["content_items", "platform text not null default 'FACEBOOK'"],
	["content_items", "content_type text not null default 'POSTER'"],
	["content_items", "status text not null default 'IDEA'"],
	["content_items", "publish_at timestamptz"],
	["content_items", "event_id text"],
	["content_items", "writer_id text"],
	["content_items", "designer_id text"],
	["content_items", "reviewer_id text"],
	["content_items", "created_by text not null default ''"],
	["content_items", "created_at timestamptz not null default now()"],
	["content_items", "updated_at timestamptz not null default now()"],
	["content_items", "deleted_at timestamptz"],
	["announcements", "title text not null default ''"],
	["announcements", "body text not null default ''"],
	["announcements", "author_id text not null default ''"],
	["announcements", "created_at timestamptz not null default now()"],
	["notifications", "title text not null default ''"],
	["notifications", "body text not null default ''"],
	["notifications", "link text"],
	["notifications", "read_at timestamptz"],
	["notifications", "created_at timestamptz not null default now()"],
	["courses", "title text not null default ''"],
	["courses", "description text not null default ''"],
	["courses", "is_public boolean not null default false"],
	["courses", "created_by text not null default ''"],
	["courses", "created_at timestamptz not null default now()"],
	["courses", "updated_at timestamptz not null default now()"],
	["courses", "deleted_at timestamptz"],
	["courses", "kind text not null default 'COURSE'"],
	["course_items", "kind text not null default 'TEXT'"],
	["course_items", "title text not null default ''"],
	["course_items", "media_url text"],
	["course_items", "extra text"],
	["course_items", "sort_order int not null default 0"],
	["course_items", "created_at timestamptz not null default now()"],
	["course_items", "course_id text"],
	["activity_logs", "actor_id text"],
	["activity_logs", "action text not null default ''"],
	["activity_logs", "entity text not null default ''"],
	["activity_logs", "entity_id text"],
	["activity_logs", "metadata text"],
	["activity_logs", "created_at timestamptz not null default now()"],
	["club_state", "value text not null default ''"],
	["content_approvals", "action text not null default ''"],
	["content_approvals", "comment text not null default ''"],
	["content_approvals", "created_at timestamptz not null default now()"]
];
function pgDefault(udt, dataType) {
	const u = `${udt} ${dataType}`.toLowerCase();
	if (u.includes("bool")) return "false";
	if (u.includes("int") || u.includes("numeric") || u.includes("decimal") || u.includes("real") || u.includes("double") || u.includes("float")) return "0";
	if (u.includes("timestamp")) return "now()";
	if (/\bdate\b/.test(u)) return "CURRENT_DATE";
	if (u.includes("json")) return `'{}'::jsonb`;
	if (u.includes("uuid")) return `'00000000-0000-0000-0000-000000000000'::uuid`;
	return "''";
}
async function tryQuery(sql, text, params = []) {
	try {
		await sql.query(text, params);
	} catch {}
}
async function columnsOf(sql, table) {
	const rows = await sql.query(`select column_name from information_schema.columns
     where table_schema = 'public' and table_name = $1`, [table]);
	return new Set(rows.map((r) => String(r.column_name)));
}
async function runHeal(sql) {
	for (const stmt of [
		`create table if not exists activity_logs (
      id text primary key, actor_id text, action text not null default '',
      entity text not null default '', entity_id text, metadata text,
      created_at timestamptz not null default now())`,
		`create table if not exists attendance (
      id text primary key, event_id text, user_id text,
      checked_at timestamptz not null default now(), method text not null default 'QR')`,
		`create table if not exists announcements (
      id text primary key, title text not null default '', body text not null default '',
      author_id text not null default '', created_at timestamptz not null default now())`,
		`create table if not exists tasks (
      id text primary key, title text not null default '', description text not null default '',
      status text not null default 'TODO', priority text not null default 'MEDIUM',
      deadline timestamptz, creator_id text not null default '', department_id text, event_id text,
      created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
      deleted_at timestamptz)`,
		`create table if not exists task_assignees (
      task_id text not null, user_id text not null, primary key (task_id, user_id))`,
		`create table if not exists courses (
      id text primary key, title text not null default '', description text not null default '',
      is_public boolean not null default false, created_by text not null default '',
      created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
      deleted_at timestamptz)`,
		`create table if not exists course_items (
      id text primary key, course_id text, kind text not null default 'TEXT',
      title text not null default '', media_url text, extra text,
      sort_order int not null default 0, created_at timestamptz not null default now())`,
		`create table if not exists content_items (
      id text primary key, title text not null default '', caption text not null default '',
      platform text not null default 'FACEBOOK', content_type text not null default 'POSTER',
      status text not null default 'IDEA', publish_at timestamptz, event_id text,
      writer_id text, designer_id text, reviewer_id text, created_by text not null default '',
      created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
      deleted_at timestamptz)`,
		`create table if not exists event_participants (
      event_id text not null, user_id text not null, joined_at timestamptz not null default now(),
      primary key (event_id, user_id))`,
		`create table if not exists notifications (
      id text primary key, user_id text not null, title text not null default '',
      body text not null default '', link text, read_at timestamptz,
      created_at timestamptz not null default now())`,
		`create table if not exists club_state (key text primary key, value text not null default '')`
	]) await tryQuery(sql, stmt);
	for (const [table, spec] of ADD_COLUMNS) await tryQuery(sql, `alter table ${table} add column if not exists ${spec}`);
	for (const table of HEAL_TABLES) {
		const cols = await sql.query(`select column_name, data_type, udt_name, column_default, is_nullable
       from information_schema.columns
       where table_schema = 'public' and table_name = $1`, [table]);
		for (const c of cols) {
			const name = String(c.column_name);
			if (!IDENT.test(name)) continue;
			if (name === "id" || name === "user_id") continue;
			if (c.is_nullable === "YES") continue;
			if (c.column_default != null && String(c.column_default).length > 0) continue;
			await tryQuery(sql, `alter table ${table} alter column "${name}" set default ${pgDefault(String(c.udt_name || ""), String(c.data_type || ""))}`);
			await tryQuery(sql, `alter table ${table} alter column "${name}" drop not null`);
		}
	}
	for (const stmt of [
		`update departments set slug = id where slug is null or slug = ''`,
		`update events set slug = id where slug is null or slug = ''`,
		`update events set checkin_token = id where checkin_token is null or checkin_token = ''`,
		`update events set title = name where name is not null and name <> ''`,
		`update events set start_at = starts_at where starts_at is not null`,
		`update events set start_at = begin_at where begin_at is not null`,
		`update events set start_at = event_date where event_date is not null`,
		`update events set location = place where place is not null and place <> ''`,
		`update events set location = venue where venue is not null and venue <> ''`,
		`update tasks set title = name where name is not null and name <> ''`,
		`update announcements set title = name where name is not null and name <> ''`,
		`update announcements set body = content where content is not null and content <> ''`,
		`update content_items set title = name where name is not null and name <> ''`,
		`update courses set title = name where name is not null and name <> ''`,
		`update course_items set kind = type where type is not null and type <> ''`,
		`update course_items set kind = item_type where item_type is not null and item_type <> ''`,
		`update course_items set title = name where name is not null and name <> ''`,
		`update attendance set checked_at = created_at where created_at is not null`,
		`update attendance set checked_at = checked_in_at where checked_in_at is not null`,
		`update attendance set checked_at = attended_at where attended_at is not null`,
		`update activity_logs set entity = target where target is not null and target <> ''`,
		`update activity_logs set entity = resource where resource is not null and resource <> ''`,
		`update activity_logs set entity = entity_type where entity_type is not null and entity_type <> ''`,
		`update profiles set full_name = name where full_name is null or full_name = ''`,
		`update department_members set position = role where position is null or position = ''`,
		`update departments set sort_order = 0 where id = 'bcn'`,
		`update departments set sort_order = 1 where id = 'members'`,
		`update departments set sort_order = 2 where id = 'media'`,
		`update departments set sort_order = 3 where id = 'academic'`,
		`update departments set sort_order = 4 where id = 'event'`
	]) await tryQuery(sql, stmt);
}
var healRef = globalThis;
async function healSchema(sql) {
	healRef.__nigotoHealV3__ ??= runHeal(sql).catch((err) => {
		healRef.__nigotoHealV3__ = void 0;
		throw err;
	});
	await healRef.__nigotoHealV3__;
}
async function insertMatching(sql, table, data, conflict) {
	const cols = await columnsOf(sql, table);
	const fields = Object.keys(data).filter((k) => IDENT.test(k) && cols.has(k));
	if (fields.length === 0) return;
	const values = fields.map((k) => data[k]);
	const placeholders = fields.map((_, i) => `$${i + 1}`).join(", ");
	let text = `insert into ${table} (${fields.join(", ")}) values (${placeholders})`;
	if (conflict) text += ` ${conflict}`;
	await sql.query(text, values);
}
async function seedDepartments(sql) {
	await healSchema(sql);
	const cols = await columnsOf(sql, "departments");
	const updates = [
		"name",
		"description",
		"sort_order",
		"slug",
		"color",
		"icon"
	].filter((c) => cols.has(c));
	const conflict = updates.length > 0 ? `on conflict (id) do update set ${updates.map((c) => `${c} = excluded.${c}`).join(", ")}` : "on conflict (id) do nothing";
	for (const d of DEPT_SEED) {
		const row = {
			id: d.id,
			name: d.name,
			description: d.description,
			sort_order: d.sort,
			slug: d.id,
			color: "",
			icon: ""
		};
		try {
			await insertMatching(sql, "departments", row, conflict);
		} catch {
			try {
				await insertMatching(sql, "departments", row);
			} catch {}
		}
	}
}
async function ensureProfile(sql, userId) {
	await seedDepartments(sql);
	const existing = await sql`select * from profiles where user_id = ${userId} limit 1`;
	if (existing[0]) return existing[0];
	const u = (await sql`select id, name, email, image from "user" where id = ${userId} limit 1`)[0];
	if (!u) throw new Error("Không tìm thấy tài khoản.");
	const first = ((await sql`select count(*)::int as n from profiles`)[0]?.n ?? 0) === 0;
	const role = first ? ROLES.PRESIDENT : ROLES.MEMBER;
	const dept = first ? "bcn" : "members";
	const position = first ? "HEAD" : "MEMBER";
	await insertMatching(sql, "profiles", {
		user_id: userId,
		full_name: u.name || "Thành viên mới",
		role,
		status: "ACTIVE",
		email: u.email || "",
		slug: userId
	});
	await insertMatching(sql, "department_members", {
		department_id: dept,
		user_id: userId,
		position
	}, "on conflict (department_id, user_id) do nothing");
	if (first) await insertMatching(sql, "club_state", {
		key: "seeded",
		value: "1"
	}, "on conflict (key) do nothing");
	return (await sql`select * from profiles where user_id = ${userId} limit 1`)[0];
}
async function syncBcnClubRole(sql, userId) {
	const bcn = (await sql`
    select department_id, position from department_members where user_id = ${userId}`).find((s) => s.department_id === "bcn");
	const role = (await sql`select role from profiles where user_id = ${userId} limit 1`)[0]?.role;
	if (role === ROLES.PRESIDENT || role === ROLES.SUPER_ADMIN) return;
	if (bcn?.position === "VICE_HEAD" && role !== ROLES.VICE_PRESIDENT) await sql`update profiles set role = ${ROLES.VICE_PRESIDENT} where user_id = ${userId}`;
	else if (role === ROLES.VICE_PRESIDENT && bcn?.position !== "VICE_HEAD") await sql`update profiles set role = ${ROLES.MEMBER} where user_id = ${userId}`;
}
async function loadActor(sql, userId) {
	const profile = await ensureProfile(sql, userId);
	await syncBcnClubRole(sql, userId);
	const p = (await sql`select * from profiles where user_id = ${userId} limit 1`)[0] ?? profile;
	const u = (await sql`select id, name, email, image from "user" where id = ${userId} limit 1`)[0];
	const orderBy = (await columnsOf(sql, "departments")).has("sort_order") ? "d.sort_order" : "d.name";
	const depts = (await sql.query(`select dm.department_id, d.name, dm.position
     from department_members dm
     join departments d on d.id = dm.department_id
     where dm.user_id = $1
     order by ${orderBy}`, [userId])).map((s) => ({
		id: s.department_id,
		name: s.name,
		position: s.position
	}));
	const inBcn = depts.some((d) => d.id === "bcn");
	const inMedia = depts.some((d) => d.id === "media");
	const inAcademic = depts.some((d) => d.id === "academic");
	const inEvent = depts.some((d) => d.id === "event");
	const role = p.role || ROLES.MEMBER;
	const isPresident = role === ROLES.PRESIDENT;
	const isVice = role === ROLES.VICE_PRESIDENT;
	const isAdmin = role === ROLES.SUPER_ADMIN || isPresident;
	const canViewStaff = isAdmin || inBcn || inMedia || inAcademic || inEvent;
	const bcnHead = depts.some((d) => d.id === "bcn" && d.position === "HEAD");
	return {
		userId,
		email: u?.email ?? "",
		name: p.full_name || u?.name || "Thành viên",
		studentId: p.student_id,
		phone: p.phone,
		birthday: p.birthday,
		role,
		status: p.status,
		joinDate: p.join_date,
		depts,
		isPresident,
		isVice,
		isAdmin,
		inBcn,
		inMedia,
		inAcademic,
		inEvent,
		membersOnly: !canViewStaff,
		canViewStaff,
		canViewCalendar: canViewStaff,
		canViewMedia: isAdmin || inBcn || inMedia,
		canCreateTask: isAdmin || inBcn,
		canCreateEvent: isAdmin || inBcn || inEvent,
		canCreateContent: isAdmin || inBcn || inMedia,
		canCreateCourse: isAdmin || inBcn || inAcademic,
		canAnnounce: isAdmin || inBcn || inMedia,
		canManagePeople: isAdmin || isVice || inBcn,
		canEditIdentity: isPresident || bcnHead || isAdmin,
		canDeleteEvent: isAdmin || inBcn || inEvent,
		canToggleCheckin: canViewStaff
	};
}
async function logActivity(sql, actorId, action, entity, entityId, metadata) {
	await insertMatching(sql, "activity_logs", {
		id: nid("log"),
		actor_id: actorId,
		action,
		entity,
		entity_id: entityId ?? null,
		metadata: metadata ?? null
	});
}
async function notify(sql, userId, title, body, link) {
	await insertMatching(sql, "notifications", {
		id: nid("nt"),
		user_id: userId,
		title,
		body,
		link: link ?? null
	});
}
async function purgeUser(sql, targetId) {
	await sql`delete from department_members where user_id = ${targetId}`;
	await sql`delete from event_participants where user_id = ${targetId}`;
	await sql`delete from attendance where user_id = ${targetId}`;
	await sql`delete from task_assignees where user_id = ${targetId}`;
	await sql`delete from task_comments where user_id = ${targetId}`;
	await sql`delete from notifications where user_id = ${targetId}`;
	await sql`delete from announcements where author_id = ${targetId}`;
	await sql`delete from profiles where user_id = ${targetId}`;
	await sql`delete from session where "userId" = ${targetId}`;
	await sql`delete from account where "userId" = ${targetId}`;
	await sql`delete from "user" where id = ${targetId}`;
}
function deny(msg = "Bạn không có quyền thực hiện thao tác này.") {
	throw new Error(msg);
}
/** Email abstraction — wire SMTP later. Preview logs only. */
async function sendEmail(opts) {
	console.info("[nigoto-email]", opts.to, opts.subject, opts.text.slice(0, 180));
	return { ok: true };
}
async function actorOf(userId) {
	const sql = await getSql();
	return {
		sql,
		me: await loadActor(sql, userId)
	};
}
function publicFlag(v) {
	return v === true || v === "true" || v === 1 || v === "t";
}
function maskIfNeeded(me, studentId) {
	if (me.membersOnly) return maskStudentId(studentId);
	return studentId || "—";
}
var getMe_createServerFn_handler = createServerRpc({
	id: "7749e2977d8573d9fb42eb288dd2cd725048dc1c975e1ed42bb8cb5b26f12aa1",
	name: "getMe",
	filename: "src/lib/server/fns.ts"
}, (opts) => getMe.__executeServer(opts));
var getMe = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getMe_createServerFn_handler, async ({ context }) => {
	const { me } = await actorOf(context.userId);
	return me;
});
var saveSignupIdentity_createServerFn_handler = createServerRpc({
	id: "ba552835f5b4018e5973f35aff4fd55fce5f12ad57106d30caa1fbbfdba0cec7",
	name: "saveSignupIdentity",
	filename: "src/lib/server/fns.ts"
}, (opts) => saveSignupIdentity.__executeServer(opts));
var saveSignupIdentity = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(saveSignupIdentity_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	const name = validateName(data.fullName);
	await sql`update profiles set full_name = ${name}, student_id = ${validateStudentId(data.studentId)}, birthday = ${validateBirthday(data.birthday)}::date
      where user_id = ${me.userId}`;
	await sql`update "user" set name = ${name} where id = ${me.userId}`;
	return loadActor(sql, me.userId);
});
var updateMyProfile_createServerFn_handler = createServerRpc({
	id: "888be06492e3caf2a53a14b4e0d15d6d3a4895b82db57153dc1e15c8a8267a05",
	name: "updateMyProfile",
	filename: "src/lib/server/fns.ts"
}, (opts) => updateMyProfile.__executeServer(opts));
var updateMyProfile = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(updateMyProfile_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	await sql`update profiles set phone = ${validatePhone(data.phone ?? "") || null} where user_id = ${me.userId}`;
	return loadActor(sql, me.userId);
});
var requestPasswordReset_createServerFn_handler = createServerRpc({
	id: "396c1077e338f51553edb5fc8dfe80064612657a7ca43ed80561872ab45db6b5",
	name: "requestPasswordReset",
	filename: "src/lib/server/fns.ts"
}, (opts) => requestPasswordReset.__executeServer(opts));
var requestPasswordReset = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(requestPasswordReset_createServerFn_handler, async ({ data }) => {
	await sendEmail({
		to: data.email,
		subject: "Đặt lại mật khẩu Nigoto Hub",
		text: "Nếu email này có tài khoản, hãy dùng form đăng nhập để tạo mật khẩu mới sau khi quản trị hỗ trợ."
	});
	return { ok: true };
});
var getDashboard_createServerFn_handler = createServerRpc({
	id: "acca3fbf74b302df3c984c5468c7a02595c98a0b51b88b96a1fe324ce9a245e4",
	name: "getDashboard",
	filename: "src/lib/server/fns.ts"
}, (opts) => getDashboard.__executeServer(opts));
var getDashboard = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getDashboard_createServerFn_handler, async ({ context }) => {
	const { sql, me } = await actorOf(context.userId);
	const memberCount = await sql`select count(*)::int as n from profiles`;
	const events = await (me.canCreateEvent ? sql`
        select id, title, start_at, location, is_public from events
        where deleted_at is null and start_at >= now() - interval '1 day'
        order by start_at asc limit 6` : sql`
        select id, title, start_at, location, is_public from events
        where deleted_at is null and is_public = true and start_at >= now() - interval '1 day'
        order by start_at asc limit 6`);
	const myTasks = me.canViewStaff ? await sql`
        select t.id, t.title, t.status, t.priority, t.deadline
        from tasks t join task_assignees a on a.task_id = t.id
        where a.user_id = ${me.userId} and t.deleted_at is null
          and t.status in ('TODO','IN_PROGRESS','REVIEW')
        order by t.deadline nulls last` : [];
	const announcements = await sql`
    select id, title, body, created_at from announcements order by created_at desc limit 5`;
	const overdue = me.canViewStaff ? await sql`select count(*)::int as n from tasks
        where deleted_at is null and status <> 'COMPLETED' and deadline < now()` : [{ n: 0 }];
	const inProgress = me.canViewStaff ? await sql`select count(*)::int as n from tasks
        where deleted_at is null and status = 'IN_PROGRESS'` : [{ n: 0 }];
	const pendingContent = me.canViewMedia ? await sql`select count(*)::int as n from content_items
        where deleted_at is null and status in ('SUBMITTED','CHANGES')` : [{ n: 0 }];
	return {
		me,
		memberCount: memberCount[0]?.n ?? 0,
		events,
		myTasks,
		announcements,
		overdue: overdue[0]?.n ?? 0,
		inProgress: inProgress[0]?.n ?? 0,
		pendingContent: pendingContent[0]?.n ?? 0
	};
});
var globalSearch_createServerFn_handler = createServerRpc({
	id: "e3493cf3bd0227d7d916e606c844703896065f5c0c78d0f7611c922c31c39bb7",
	name: "globalSearch",
	filename: "src/lib/server/fns.ts"
}, (opts) => globalSearch.__executeServer(opts));
var globalSearch = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(globalSearch_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	const q = `%${data.q.trim().slice(0, 60)}%`;
	if (data.q.trim().length < 2) return {
		people: [],
		events: [],
		tasks: [],
		content: []
	};
	const people = await sql`
      select user_id, full_name, student_id from profiles
      where full_name ilike ${q} or student_id ilike ${q} limit 8`;
	const events = me.canCreateEvent ? await sql`select id, title from events where deleted_at is null and title ilike ${q} limit 6` : await sql`select id, title from events where deleted_at is null and is_public = true and title ilike ${q} limit 6`;
	const tasks = me.canViewStaff ? await sql`select id, title from tasks where deleted_at is null and title ilike ${q} limit 6` : [];
	const content = me.canViewMedia ? await sql`select id, title from content_items where deleted_at is null and title ilike ${q} limit 6` : [];
	return {
		people: people.map((p) => ({
			...p,
			student_id: maskIfNeeded(me, p.student_id)
		})),
		events,
		tasks,
		content
	};
});
var listMembers_createServerFn_handler = createServerRpc({
	id: "9b7da1deb93862c6dfd903580e0bff04e5ba971c523f1798a8c61a03c10cf11b",
	name: "listMembers",
	filename: "src/lib/server/fns.ts"
}, (opts) => listMembers.__executeServer(opts));
var listMembers = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listMembers_createServerFn_handler, async ({ context }) => {
	const { sql, me } = await actorOf(context.userId);
	return (await sql`
    select p.user_id, p.full_name, p.student_id, p.role, p.status, u.email,
      string_agg(d.name, ', ' order by d.sort_order) as depts
    from profiles p
    join "user" u on u.id = p.user_id
    left join department_members dm on dm.user_id = p.user_id
    left join departments d on d.id = dm.department_id
    group by p.user_id, p.full_name, p.student_id, p.role, p.status, u.email
    order by p.full_name`).map((r) => ({
		...r,
		student_id: maskIfNeeded(me, r.student_id)
	}));
});
var getMember_createServerFn_handler = createServerRpc({
	id: "ca7af9087eb58e7786977249d7a411a57f2bbeafc4334977ff36d70612fec9b0",
	name: "getMember",
	filename: "src/lib/server/fns.ts"
}, (opts) => getMember.__executeServer(opts));
var getMember = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(getMember_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	const p = (await sql`
      select p.*, u.email from profiles p
      join "user" u on u.id = p.user_id
      where p.user_id = ${data.id} limit 1`)[0];
	if (!p) throw new Error("Không tìm thấy thành viên.");
	const depts = await sql`
      select dm.department_id, d.name, dm.position
      from department_members dm join departments d on d.id = dm.department_id
      where dm.user_id = ${data.id}`;
	const attended = await sql`select count(*)::int as n from attendance where user_id = ${data.id}`;
	const tasksDone = me.canViewStaff ? await sql`
          select count(*)::int as n from tasks t join task_assignees a on a.task_id = t.id
          where a.user_id = ${data.id} and t.status = 'COMPLETED' and t.deleted_at is null` : [{ n: 0 }];
	const tasksOpen = me.canViewStaff ? await sql`
          select count(*)::int as n from tasks t join task_assignees a on a.task_id = t.id
          where a.user_id = ${data.id} and t.status <> 'COMPLETED' and t.deleted_at is null` : [{ n: 0 }];
	return {
		...p,
		student_id: maskIfNeeded(me, p.student_id),
		student_id_raw: me.membersOnly ? null : p.student_id,
		phone: p.phone,
		depts,
		attended: attended[0]?.n ?? 0,
		tasksDone: tasksDone[0]?.n ?? 0,
		tasksOpen: tasksOpen[0]?.n ?? 0,
		canEdit: me.canEditIdentity,
		canManage: me.canManagePeople,
		viewer: me
	};
});
var patchMember_createServerFn_handler = createServerRpc({
	id: "21e2970703733646a2bf9d1c4ffaddc65f1e323df245ca72b848d1a183a12693",
	name: "patchMember",
	filename: "src/lib/server/fns.ts"
}, (opts) => patchMember.__executeServer(opts));
var patchMember = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(patchMember_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canManagePeople) deny();
	if (!(await sql`select role from profiles where user_id = ${data.id} limit 1`)[0]) throw new Error("Không tìm thấy thành viên.");
	if (data.fullName || data.studentId || data.birthday || data.email) {
		if (!me.canEditIdentity) deny("Chỉ Chủ nhiệm được đổi họ tên, MSSV, ngày sinh và email.");
	}
	if (data.fullName) {
		const name = validateName(data.fullName);
		await sql`update profiles set full_name = ${name} where user_id = ${data.id}`;
		await sql`update "user" set name = ${name} where id = ${data.id}`;
	}
	if (data.studentId) await sql`update profiles set student_id = ${validateStudentId(data.studentId)} where user_id = ${data.id}`;
	if (data.birthday) await sql`update profiles set birthday = ${validateBirthday(data.birthday)}::date where user_id = ${data.id}`;
	if (data.phone !== void 0) await sql`update profiles set phone = ${validatePhone(data.phone) || null} where user_id = ${data.id}`;
	if (data.email) {
		const email = data.email.trim().toLowerCase();
		if ((await sql`select id from "user" where email = ${email} and id <> ${data.id} limit 1`)[0]) throw new Error("Email này đã được dùng.");
		await sql`update "user" set email = ${email} where id = ${data.id}`;
	}
	if (data.role && Object.values(ROLES).includes(data.role)) {
		if (data.id === me.userId && me.isPresident && data.role !== ROLES.PRESIDENT) {
			if (((await sql`select count(*)::int as n from profiles where role = ${ROLES.PRESIDENT} and user_id <> ${me.userId}`)[0]?.n ?? 0) === 0) deny("Không thể hạ Chủ nhiệm cuối cùng.");
		}
		await sql`update profiles set role = ${data.role} where user_id = ${data.id}`;
	}
	if (data.status && STATUSES.includes(data.status)) await sql`update profiles set status = ${data.status} where user_id = ${data.id}`;
	await logActivity(sql, me.userId, "patch_member", "profile", data.id);
	return { ok: true };
});
var deleteMember_createServerFn_handler = createServerRpc({
	id: "a00e9c34ec5669e08ed40691003183cd24f7021b685fa27e2002e9b22745d993",
	name: "deleteMember",
	filename: "src/lib/server/fns.ts"
}, (opts) => deleteMember.__executeServer(opts));
var deleteMember = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(deleteMember_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canManagePeople) deny();
	if (data.id === me.userId) deny("Không thể xóa chính mình.");
	if ((await sql`select role from profiles where user_id = ${data.id} limit 1`)[0]?.role === ROLES.PRESIDENT) {
		if (((await sql`select count(*)::int as n from profiles where role = ${ROLES.PRESIDENT}`)[0]?.n ?? 0) <= 1) deny("Không thể xóa Chủ nhiệm cuối.");
	}
	await purgeUser(sql, data.id);
	await logActivity(sql, me.userId, "delete_member", "profile", data.id);
	return { ok: true };
});
var listDepartments_createServerFn_handler = createServerRpc({
	id: "0ce251a1cf2b3a6c9fcc43fa4155cb0bef09c6962fb10f5435d445b0b45727cf",
	name: "listDepartments",
	filename: "src/lib/server/fns.ts"
}, (opts) => listDepartments.__executeServer(opts));
var listDepartments = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listDepartments_createServerFn_handler, async ({ context }) => {
	const { sql } = await actorOf(context.userId);
	return await sql`
    select d.id, d.name, d.description, count(dm.user_id)::int as n
    from departments d
    left join department_members dm on dm.department_id = d.id
    group by d.id, d.name, d.description, d.sort_order
    order by d.sort_order`;
});
var getDepartment_createServerFn_handler = createServerRpc({
	id: "f6b2a76acaa62de98d5edf783ec5306a80603bee86f0e9021a0ffffcc1e41b06",
	name: "getDepartment",
	filename: "src/lib/server/fns.ts"
}, (opts) => getDepartment.__executeServer(opts));
var getDepartment = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(getDepartment_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	const dept = (await sql`
      select id, name, description from departments where id = ${data.id} limit 1`)[0];
	if (!dept) throw new Error("Không tìm thấy ban.");
	const members = await sql`
      select p.user_id, p.full_name, dm.position, p.student_id, p.role
      from department_members dm
      join profiles p on p.user_id = dm.user_id
      where dm.department_id = ${data.id}
      order by case dm.position when 'HEAD' then 0 when 'VICE_HEAD' then 1 else 2 end, p.full_name`;
	return {
		...dept,
		members: members.map((m) => ({
			...m,
			student_id: maskIfNeeded(me, m.student_id)
		})),
		canManage: me.canManagePeople
	};
});
var assignDepartmentMember_createServerFn_handler = createServerRpc({
	id: "1b46f8132c42db28df268b72dba3e1a05c002709bb97015794a42b9336df01d0",
	name: "assignDepartmentMember",
	filename: "src/lib/server/fns.ts"
}, (opts) => assignDepartmentMember.__executeServer(opts));
var assignDepartmentMember = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(assignDepartmentMember_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canManagePeople) deny();
	if (!POSITIONS.includes(data.position)) throw new Error("Chức vụ không hợp lệ.");
	await sql`insert into department_members (department_id, user_id, position)
      values (${data.departmentId}, ${data.userId}, ${data.position})
      on conflict (department_id, user_id) do update set position = excluded.position`;
	await logActivity(sql, me.userId, "assign_dept", "department", data.departmentId, data.userId);
	return { ok: true };
});
var removeDepartmentMember_createServerFn_handler = createServerRpc({
	id: "1ece894a2011a8ed9de6dceed360021a754a38625999ecb1df99babef1b3fabe",
	name: "removeDepartmentMember",
	filename: "src/lib/server/fns.ts"
}, (opts) => removeDepartmentMember.__executeServer(opts));
var removeDepartmentMember = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(removeDepartmentMember_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canManagePeople) deny();
	await sql`delete from department_members where department_id = ${data.departmentId} and user_id = ${data.userId}`;
	return { ok: true };
});
var listEvents_createServerFn_handler = createServerRpc({
	id: "530839d64b9e7f530c678a40e0cd83b68d89cb3ade688966ad9210866de07ce0",
	name: "listEvents",
	filename: "src/lib/server/fns.ts"
}, (opts) => listEvents.__executeServer(opts));
var listEvents = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listEvents_createServerFn_handler, async ({ context }) => {
	const { sql, me } = await actorOf(context.userId);
	return (me.canCreateEvent ? await sql`select * from events where deleted_at is null order by start_at desc` : await sql`select * from events where deleted_at is null and is_public = true order by start_at desc`).map((e) => ({
		...e,
		checkin_token: me.canToggleCheckin ? e.checkin_token : "",
		is_public: publicFlag(e.is_public),
		checkin_open: publicFlag(e.checkin_open)
	}));
});
var getEvent_createServerFn_handler = createServerRpc({
	id: "cc94f8b3b1332e44197e162a01cf9e290d60875cc6527b8d1deab8c3583efca6",
	name: "getEvent",
	filename: "src/lib/server/fns.ts"
}, (opts) => getEvent.__executeServer(opts));
var getEvent = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(getEvent_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	const e = (await sql`select * from events where id = ${data.id} and deleted_at is null limit 1`)[0];
	if (!e) throw new Error("Không tìm thấy sự kiện.");
	if (!publicFlag(e.is_public) && !me.canCreateEvent) deny("Sự kiện chưa công bố.");
	const joined = await sql`select count(*)::int as n from event_participants where event_id = ${e.id}`;
	const attended = await sql`select count(*)::int as n from attendance where event_id = ${e.id}`;
	const mine = await sql`select count(*)::int as n from event_participants where event_id = ${e.id} and user_id = ${me.userId}`;
	const myAtt = await sql`select count(*)::int as n from attendance where event_id = ${e.id} and user_id = ${me.userId}`;
	const people = me.canToggleCheckin ? await sql`
          select p.user_id, p.full_name, a.checked_at
          from event_participants ep
          join profiles p on p.user_id = ep.user_id
          left join attendance a on a.event_id = ep.event_id and a.user_id = ep.user_id
          where ep.event_id = ${e.id}
          order by p.full_name` : [];
	return {
		...e,
		is_public: publicFlag(e.is_public),
		checkin_open: publicFlag(e.checkin_open),
		checkin_token: me.canToggleCheckin ? e.checkin_token : "",
		joined: joined[0]?.n ?? 0,
		attended: attended[0]?.n ?? 0,
		iJoined: (mine[0]?.n ?? 0) > 0,
		iAttended: (myAtt[0]?.n ?? 0) > 0,
		people,
		canEdit: me.canCreateEvent,
		canPublish: me.inBcn || me.isAdmin,
		canCheckinToggle: me.canToggleCheckin
	};
});
var saveEvent_createServerFn_handler = createServerRpc({
	id: "60da22b6ac526dc7fef3ea968232e29442ea495adaa693fa988f6e01e6bd9574",
	name: "saveEvent",
	filename: "src/lib/server/fns.ts"
}, (opts) => saveEvent.__executeServer(opts));
var saveEvent = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(saveEvent_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canCreateEvent) deny();
	const title = validateTitle(data.title);
	const description = validateDesc(data.description);
	const id = data.id || nid("evt");
	const token = nid("qr");
	if (data.id) await sql`update events set
        title = ${title}, description = ${description}, event_type = ${data.event_type},
        status = ${data.status}, location = ${data.location}, start_at = ${data.start_at}::timestamptz,
        end_at = ${data.end_at ? data.end_at : null}, cover_url = ${data.cover_url || null},
        updated_at = now()
        where id = ${id} and deleted_at is null`;
	else await sql`insert into events
        (id, title, description, event_type, status, location, start_at, end_at, cover_url, is_public, checkin_open, checkin_token, organizer_id)
        values (${id}, ${title}, ${description}, ${data.event_type}, ${data.status}, ${data.location},
          ${data.start_at}::timestamptz, ${data.end_at ? data.end_at : null}, ${data.cover_url || null},
          ${!!data.is_public}, ${true}, ${token}, ${me.userId})`;
	await logActivity(sql, me.userId, data.id ? "update_event" : "create_event", "event", id);
	return { id };
});
var setEventPublic_createServerFn_handler = createServerRpc({
	id: "8ce44e30c29abf13ec656d6d24ec56f6d35828d80ab6ecc57750a130d804d3be",
	name: "setEventPublic",
	filename: "src/lib/server/fns.ts"
}, (opts) => setEventPublic.__executeServer(opts));
var setEventPublic = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(setEventPublic_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.inBcn && !me.isAdmin) deny();
	await sql`update events set is_public = ${data.is_public}, updated_at = now() where id = ${data.id}`;
	return { ok: true };
});
var deleteEvent_createServerFn_handler = createServerRpc({
	id: "bc5d90460841ecbe113ae56d7405f48221c4bf854c803a7aca65b56a76a54ec2",
	name: "deleteEvent",
	filename: "src/lib/server/fns.ts"
}, (opts) => deleteEvent.__executeServer(opts));
var deleteEvent = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(deleteEvent_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canDeleteEvent) deny();
	await sql`update events set deleted_at = now() where id = ${data.id}`;
	return { ok: true };
});
var joinEvent_createServerFn_handler = createServerRpc({
	id: "68c8ae89e7012e06fffd14560a8c1ee7d03cd173920cc7f3473960d7e90fbd38",
	name: "joinEvent",
	filename: "src/lib/server/fns.ts"
}, (opts) => joinEvent.__executeServer(opts));
var joinEvent = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(joinEvent_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	const e = await sql`select is_public from events where id = ${data.id} and deleted_at is null`;
	if (!e[0]) throw new Error("Không tìm thấy sự kiện.");
	if (!publicFlag(e[0].is_public) && !me.canCreateEvent) deny();
	await sql`insert into event_participants (event_id, user_id) values (${data.id}, ${me.userId}) on conflict do nothing`;
	return { ok: true };
});
var listAttendanceEvents_createServerFn_handler = createServerRpc({
	id: "78e359e864b7d99ffa16caeae777853ded4b9097955eb680ee2b0f903c6bec18",
	name: "listAttendanceEvents",
	filename: "src/lib/server/fns.ts"
}, (opts) => listAttendanceEvents.__executeServer(opts));
var listAttendanceEvents = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listAttendanceEvents_createServerFn_handler, async ({ context }) => {
	const { sql, me } = await actorOf(context.userId);
	const rows = me.canCreateEvent ? await sql`select * from events where deleted_at is null order by start_at desc` : await sql`select * from events where deleted_at is null and is_public = true order by start_at desc`;
	const out = [];
	for (const e of rows) {
		const att = await sql`select count(*)::int as n from attendance where event_id = ${e.id}`;
		const mine = await sql`select count(*)::int as n from attendance where event_id = ${e.id} and user_id = ${me.userId}`;
		out.push({
			id: e.id,
			title: e.title,
			start_at: e.start_at,
			location: e.location,
			is_public: publicFlag(e.is_public),
			checkin_open: publicFlag(e.checkin_open),
			checkin_token: me.canToggleCheckin ? e.checkin_token : "",
			attended_count: me.canToggleCheckin ? att[0]?.n ?? 0 : 0,
			attended: (mine[0]?.n ?? 0) > 0
		});
	}
	return {
		me,
		events: out
	};
});
var setCheckinOpen_createServerFn_handler = createServerRpc({
	id: "5de11b3da47993a000f3823c721adf90135345f8c186a1540c62e151107b0d1a",
	name: "setCheckinOpen",
	filename: "src/lib/server/fns.ts"
}, (opts) => setCheckinOpen.__executeServer(opts));
var setCheckinOpen = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(setCheckinOpen_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canToggleCheckin) deny();
	await sql`update events set checkin_open = ${data.open}, updated_at = now() where id = ${data.id}`;
	return { ok: true };
});
var checkinEvent_createServerFn_handler = createServerRpc({
	id: "157b1b335af15feda9cbc4ca56d07bc2987a5d23a81033a1906446909c06c572",
	name: "checkinEvent",
	filename: "src/lib/server/fns.ts"
}, (opts) => checkinEvent.__executeServer(opts));
var checkinEvent = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(checkinEvent_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	const e = await sql`
      select id, checkin_open, title from events where id = ${data.eventId} and deleted_at is null limit 1`;
	if (!e[0]) throw new Error("Không tìm thấy sự kiện.");
	if (!publicFlag(e[0].checkin_open)) throw new Error("Điểm danh đã đóng. Ban quản trị chưa nhận thêm.");
	await sql`insert into event_participants (event_id, user_id) values (${data.eventId}, ${me.userId}) on conflict do nothing`;
	await sql`insert into attendance (id, event_id, user_id, method)
      values (${nid("att")}, ${data.eventId}, ${me.userId}, ${data.method || "QR"})
      on conflict (event_id, user_id) do nothing`;
	return {
		ok: true,
		title: e[0].title
	};
});
var manualCheckin_createServerFn_handler = createServerRpc({
	id: "9de929fc680f3f16f4c31e7b58fd76506508eb75fac99249de00d5a567184268",
	name: "manualCheckin",
	filename: "src/lib/server/fns.ts"
}, (opts) => manualCheckin.__executeServer(opts));
var manualCheckin = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(manualCheckin_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canToggleCheckin) deny();
	await sql`insert into event_participants (event_id, user_id) values (${data.eventId}, ${data.userId}) on conflict do nothing`;
	await sql`insert into attendance (id, event_id, user_id, method)
      values (${nid("att")}, ${data.eventId}, ${data.userId}, ${"MANUAL"})
      on conflict (event_id, user_id) do nothing`;
	return { ok: true };
});
var listTasks_createServerFn_handler = createServerRpc({
	id: "8e7a859a59a76980285b1e104f6340edaea5c57db7a5490cb6e1f5132cf3918f",
	name: "listTasks",
	filename: "src/lib/server/fns.ts"
}, (opts) => listTasks.__executeServer(opts));
var listTasks = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listTasks_createServerFn_handler, async ({ context }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canViewStaff) deny();
	const tasks = await sql`select id, title, description, status, priority, deadline, creator_id, department_id
     from tasks where deleted_at is null order by created_at desc`;
	const assignees = await sql`
    select a.task_id, a.user_id, p.full_name
    from task_assignees a join profiles p on p.user_id = a.user_id`;
	const byTask = {};
	for (const a of assignees) (byTask[a.task_id] ??= []).push({
		user_id: a.user_id,
		full_name: a.full_name
	});
	return {
		me,
		tasks: tasks.map((t) => ({
			...t,
			assignees: byTask[t.id] ?? [],
			overdue: !!(t.deadline && t.status !== "COMPLETED" && new Date(t.deadline).getTime() < Date.now())
		}))
	};
});
var saveTask_createServerFn_handler = createServerRpc({
	id: "5fcb989a01f80c5a9fdb108e3258433e2682c4511b436fa68efb17b5bcb348fd",
	name: "saveTask",
	filename: "src/lib/server/fns.ts"
}, (opts) => saveTask.__executeServer(opts));
var saveTask = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(saveTask_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canCreateTask) deny();
	const title = validateTitle(data.title);
	const description = validateDesc(data.description);
	const id = data.id || nid("task");
	if (data.id) {
		await sql`update tasks set title = ${title}, description = ${description}, status = ${data.status},
        priority = ${data.priority}, deadline = ${data.deadline || null}, department_id = ${data.department_id || null},
        updated_at = now() where id = ${id}`;
		await sql`delete from task_assignees where task_id = ${id}`;
	} else await sql`insert into tasks (id, title, description, status, priority, deadline, creator_id, department_id)
        values (${id}, ${title}, ${description}, ${data.status}, ${data.priority}, ${data.deadline || null}, ${me.userId}, ${data.department_id || null})`;
	for (const uid of data.assigneeIds ?? []) {
		await sql`insert into task_assignees (task_id, user_id) values (${id}, ${uid}) on conflict do nothing`;
		if (!data.id) await notify(sql, uid, "Bạn được giao việc mới", title, "/tasks");
	}
	return { id };
});
var setTaskStatus_createServerFn_handler = createServerRpc({
	id: "a3c9bb7e6c7dc8efc756c05be54dd962b9db86e58fca323e3f148e7b95ef0139",
	name: "setTaskStatus",
	filename: "src/lib/server/fns.ts"
}, (opts) => setTaskStatus.__executeServer(opts));
var setTaskStatus = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(setTaskStatus_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	const assigned = await sql`select count(*)::int as n from task_assignees where task_id = ${data.id} and user_id = ${me.userId}`;
	if (!me.canCreateTask && (assigned[0]?.n ?? 0) === 0) deny();
	await sql`update tasks set status = ${data.status}, updated_at = now() where id = ${data.id}`;
	return { ok: true };
});
var deleteTask_createServerFn_handler = createServerRpc({
	id: "22b58fa969d3f127bb3dbce25dfdf23b75f7143eadca4c97308f27010349ea0c",
	name: "deleteTask",
	filename: "src/lib/server/fns.ts"
}, (opts) => deleteTask.__executeServer(opts));
var deleteTask = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(deleteTask_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canCreateTask) deny();
	await sql`update tasks set deleted_at = now() where id = ${data.id}`;
	return { ok: true };
});
var listContent_createServerFn_handler = createServerRpc({
	id: "3b2ca3673a2cd88d3a3f922d17e5466ab136e0f4f4ca8626140ecd3be27e05d3",
	name: "listContent",
	filename: "src/lib/server/fns.ts"
}, (opts) => listContent.__executeServer(opts));
var listContent = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listContent_createServerFn_handler, async ({ context }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canViewMedia) deny();
	return {
		me,
		items: await sql`select id, title, caption, platform, content_type, status, publish_at, created_by, writer_id
     from content_items where deleted_at is null order by coalesce(publish_at, created_at) desc`
	};
});
var saveContent_createServerFn_handler = createServerRpc({
	id: "50f873465a8c442498c9efb99627d13d3d91bdf4ca714f2209f5231c7bdf48f5",
	name: "saveContent",
	filename: "src/lib/server/fns.ts"
}, (opts) => saveContent.__executeServer(opts));
var saveContent = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(saveContent_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canCreateContent) deny("Chỉ Ban Truyền thông và Ban Chủ nhiệm được tạo nội dung.");
	const title = validateTitle(data.title);
	const caption = validateDesc(data.caption);
	if (!data.publish_at) throw new Error("Phải chọn ngày giờ đăng trên lịch.");
	const when = new Date(data.publish_at);
	if (Number.isNaN(when.getTime())) throw new Error("Ngày giờ đăng không hợp lệ.");
	const id = data.id || nid("ct");
	const status = data.status || "IDEA";
	const publish = when.toISOString();
	if (data.id) await sql`update content_items set title = ${title}, caption = ${caption}, platform = ${data.platform},
        content_type = ${data.content_type}, publish_at = ${publish}, event_id = ${data.event_id || null},
        status = ${status}, updated_at = now() where id = ${id}`;
	else await sql`insert into content_items
        (id, title, caption, platform, content_type, status, publish_at, event_id, writer_id, created_by)
        values (${id}, ${title}, ${caption}, ${data.platform}, ${data.content_type}, ${status},
          ${publish}, ${data.event_id || null}, ${me.userId}, ${me.userId})`;
	return { id };
});
var reviewContent_createServerFn_handler = createServerRpc({
	id: "d667e0be9dfbfca59ef1081de6587ce80522cd7c92e1f49ca944ec95719e8a13",
	name: "reviewContent",
	filename: "src/lib/server/fns.ts"
}, (opts) => reviewContent.__executeServer(opts));
var reviewContent = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(reviewContent_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canCreateContent) deny();
	const status = {
		SUBMIT: "SUBMITTED",
		APPROVE: "APPROVED",
		REJECT: "REJECTED",
		CHANGES: "CHANGES"
	}[data.action];
	if (!status) throw new Error("Thao tác duyệt không hợp lệ.");
	if ((data.action === "REJECT" || data.action === "CHANGES") && !data.comment.trim()) throw new Error("Cần ghi chú khi từ chối hoặc yêu cầu sửa.");
	await sql`update content_items set status = ${status}, reviewer_id = ${me.userId}, updated_at = now() where id = ${data.id}`;
	await sql`insert into content_approvals (id, content_id, actor_id, action, comment)
      values (${nid("ap")}, ${data.id}, ${me.userId}, ${data.action}, ${clip(data.comment, LIMITS.description)})`;
	return { ok: true };
});
var deleteContent_createServerFn_handler = createServerRpc({
	id: "6cb76a1a3f29b7e93db8c4c0fd5503a2e2b8919c1791a244871d6b22ea16c0e3",
	name: "deleteContent",
	filename: "src/lib/server/fns.ts"
}, (opts) => deleteContent.__executeServer(opts));
var deleteContent = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(deleteContent_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canCreateContent) deny();
	await sql`update content_items set deleted_at = now() where id = ${data.id}`;
	return { ok: true };
});
var listCalendar_createServerFn_handler = createServerRpc({
	id: "e2bae04c52ab91be499d941439758a6ad0eb1775131bf5b70b40dc711897e8d1",
	name: "listCalendar",
	filename: "src/lib/server/fns.ts"
}, (opts) => listCalendar.__executeServer(opts));
var listCalendar = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listCalendar_createServerFn_handler, async ({ context }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canViewCalendar) deny();
	const events = me.canCreateEvent ? await sql`
        select id, title, start_at, 'event' as kind from events where deleted_at is null` : await sql`
        select id, title, start_at, 'event' as kind from events where deleted_at is null and is_public = true`;
	const posts = me.canViewMedia ? await sql`
        select id, title, publish_at as start_at, 'content' as kind from content_items
        where deleted_at is null and publish_at is not null` : [];
	return {
		me,
		items: [...events, ...posts]
	};
});
var listAnnouncements_createServerFn_handler = createServerRpc({
	id: "09eef9635d1cd8dccf9e660d1a2e7bb6459d4ecac8cbcbf618062906a929e3dc",
	name: "listAnnouncements",
	filename: "src/lib/server/fns.ts"
}, (opts) => listAnnouncements.__executeServer(opts));
var listAnnouncements = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listAnnouncements_createServerFn_handler, async ({ context }) => {
	const { sql, me } = await actorOf(context.userId);
	return {
		me,
		rows: await sql`
    select a.id, a.title, a.body, a.created_at, a.author_id, p.full_name as author
    from announcements a join profiles p on p.user_id = a.author_id
    order by a.created_at desc`
	};
});
var saveAnnouncement_createServerFn_handler = createServerRpc({
	id: "17a76202d45e68c9865a152c21f82cd3f32a480c764389f7f5896fe70ad9e2eb",
	name: "saveAnnouncement",
	filename: "src/lib/server/fns.ts"
}, (opts) => saveAnnouncement.__executeServer(opts));
var saveAnnouncement = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(saveAnnouncement_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canAnnounce) deny();
	const title = validateTitle(data.title);
	const body = validateDesc(data.body);
	const id = nid("an");
	await sql`insert into announcements (id, title, body, author_id) values (${id}, ${title}, ${body}, ${me.userId})`;
	const people = await sql`select user_id from profiles`;
	for (const p of people) await notify(sql, p.user_id, title, body, "/notifications");
	return { id };
});
var deleteAnnouncement_createServerFn_handler = createServerRpc({
	id: "e42f6cb064f5b254f98f8397cb38a86a9e986e4841360bd7b75d884f709562af",
	name: "deleteAnnouncement",
	filename: "src/lib/server/fns.ts"
}, (opts) => deleteAnnouncement.__executeServer(opts));
var deleteAnnouncement = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(deleteAnnouncement_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canAnnounce) deny();
	await sql`delete from announcements where id = ${data.id}`;
	return { ok: true };
});
var listNotifications_createServerFn_handler = createServerRpc({
	id: "4b7c74445b8a677f03c5007fec61ada7c69581953c832b505253b8eb5664d0a9",
	name: "listNotifications",
	filename: "src/lib/server/fns.ts"
}, (opts) => listNotifications.__executeServer(opts));
var listNotifications = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listNotifications_createServerFn_handler, async ({ context }) => {
	const { sql, me } = await actorOf(context.userId);
	const rows = await sql`select id, title, body, link, read_at, created_at from notifications
     where user_id = ${me.userId} order by created_at desc limit 80`;
	return {
		me,
		rows,
		unread: rows.filter((r) => !r.read_at).length
	};
});
var markNotificationsRead_createServerFn_handler = createServerRpc({
	id: "1faf4fb973ae17893b2883efbf91dd4795c92133d809485a348e452d75632c2c",
	name: "markNotificationsRead",
	filename: "src/lib/server/fns.ts"
}, (opts) => markNotificationsRead.__executeServer(opts));
var markNotificationsRead = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(markNotificationsRead_createServerFn_handler, async ({ context }) => {
	const { sql, me } = await actorOf(context.userId);
	await sql`update notifications set read_at = now() where user_id = ${me.userId} and read_at is null`;
	return { ok: true };
});
var listCourses_createServerFn_handler = createServerRpc({
	id: "170b056adc2390ee8084f105f76b81417e1975bb19cf0bd60f2ca420138d87ce",
	name: "listCourses",
	filename: "src/lib/server/fns.ts"
}, (opts) => listCourses.__executeServer(opts));
var listCourses = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listCourses_createServerFn_handler, async ({ context }) => {
	const { sql, me } = await actorOf(context.userId);
	return {
		me,
		rows: (me.canCreateCourse ? await sql`
        select id, title, description, is_public from courses where deleted_at is null order by created_at desc` : await sql`
        select id, title, description, is_public from courses where deleted_at is null and is_public = true order by created_at desc`).map((r) => ({
			...r,
			is_public: publicFlag(r.is_public)
		}))
	};
});
var getCourse_createServerFn_handler = createServerRpc({
	id: "eafb4c68bd9e1161d9221186ecd4a5c6cfa5dd1f3d55fa84a7a41acf6cb43776",
	name: "getCourse",
	filename: "src/lib/server/fns.ts"
}, (opts) => getCourse.__executeServer(opts));
var getCourse = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(getCourse_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	const c = (await sql`select id, title, description, is_public, created_by from courses where id = ${data.id} and deleted_at is null`)[0];
	if (!c) throw new Error("Không tìm thấy khóa học.");
	if (!publicFlag(c.is_public) && !me.canCreateCourse) deny();
	const items = await sql`select id, kind, title, media_url, extra, sort_order from course_items where course_id = ${c.id} order by sort_order, created_at`;
	return {
		...c,
		is_public: publicFlag(c.is_public),
		items,
		canEdit: me.canCreateCourse
	};
});
var saveCourse_createServerFn_handler = createServerRpc({
	id: "60aae911292ad73bbb4d694f85301ef435dc0140233a6d4643c4e1a3f9492ee3",
	name: "saveCourse",
	filename: "src/lib/server/fns.ts"
}, (opts) => saveCourse.__executeServer(opts));
var saveCourse = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(saveCourse_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canCreateCourse) deny();
	const title = validateTitle(data.title);
	const description = validateDesc(data.description);
	const id = data.id || nid("crs");
	if (data.id) await sql`update courses set title = ${title}, description = ${description}, updated_at = now() where id = ${id}`;
	else await sql`insert into courses (id, title, description, is_public, created_by)
        values (${id}, ${title}, ${description}, ${!!data.is_public}, ${me.userId})`;
	return { id };
});
var setCoursePublic_createServerFn_handler = createServerRpc({
	id: "435b91bb78e7093d10cc2d797126d7683b00135145d20d3acc3c32ef7d2cee25",
	name: "setCoursePublic",
	filename: "src/lib/server/fns.ts"
}, (opts) => setCoursePublic.__executeServer(opts));
var setCoursePublic = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(setCoursePublic_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canCreateCourse) deny();
	await sql`update courses set is_public = ${data.is_public} where id = ${data.id}`;
	return { ok: true };
});
var deleteCourse_createServerFn_handler = createServerRpc({
	id: "57656bb58956ede032de91018eb86cc8f2416928f3821937fc223d408fdab08e",
	name: "deleteCourse",
	filename: "src/lib/server/fns.ts"
}, (opts) => deleteCourse.__executeServer(opts));
var deleteCourse = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(deleteCourse_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canCreateCourse) deny();
	await sql`update courses set deleted_at = now() where id = ${data.id}`;
	return { ok: true };
});
var saveCourseItem_createServerFn_handler = createServerRpc({
	id: "1c0b78b815515f5f0b255d4bee9ef6f1da28087fb268981622de8f6bda3d8a00",
	name: "saveCourseItem",
	filename: "src/lib/server/fns.ts"
}, (opts) => saveCourseItem.__executeServer(opts));
var saveCourseItem = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(saveCourseItem_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canCreateCourse) deny();
	const title = validateTitle(data.title);
	if (data.kind === "VIDEO" && data.media_url && data.media_url.startsWith("data:") && data.media_url.length > LIMITS.videoBytes * 1.4) throw new Error("Video tối đa 8MB. File lớn hơn hãy dùng Google Drive.");
	await sql`insert into course_items (id, course_id, kind, title, media_url, extra)
      values (${nid("ci")}, ${data.courseId}, ${data.kind}, ${title}, ${data.media_url || null}, ${data.extra || null})`;
	return { ok: true };
});
var deleteCourseItem_createServerFn_handler = createServerRpc({
	id: "db71e4b3b8539ccc0640a5023d6d865387ea114f4f7f77e754a93f975f5ef51e",
	name: "deleteCourseItem",
	filename: "src/lib/server/fns.ts"
}, (opts) => deleteCourseItem.__executeServer(opts));
var deleteCourseItem = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((d) => d).handler(deleteCourseItem_createServerFn_handler, async ({ context, data }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canCreateCourse) deny();
	await sql`delete from course_items where id = ${data.id}`;
	return { ok: true };
});
var getAnalytics_createServerFn_handler = createServerRpc({
	id: "abc60e14b4bfb39fa0ea6273dfec4baf7482f9a9cee8fb6274406bfc2e979615",
	name: "getAnalytics",
	filename: "src/lib/server/fns.ts"
}, (opts) => getAnalytics.__executeServer(opts));
var getAnalytics = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(getAnalytics_createServerFn_handler, async ({ context }) => {
	const { sql, me } = await actorOf(context.userId);
	if (!me.canViewStaff) deny();
	const byDept = await sql`
    select d.name, count(dm.user_id)::int as n
    from departments d left join department_members dm on dm.department_id = d.id
    group by d.name, d.sort_order order by d.sort_order`;
	const byStatus = await sql`
    select status, count(*)::int as n from profiles group by status`;
	const tasks = await sql`
    select status, count(*)::int as n from tasks where deleted_at is null group by status`;
	const overdue = await sql`select count(*)::int as n from tasks
    where deleted_at is null and status <> 'COMPLETED' and deadline < now()`;
	const events = await sql`select count(*)::int as n from events where deleted_at is null`;
	const logs = await sql`
    select l.id, l.action, l.entity, l.created_at, p.full_name as actor
    from activity_logs l left join profiles p on p.user_id = l.actor_id
    order by l.created_at desc limit 20`;
	return {
		me,
		byDept,
		byStatus,
		tasks,
		overdue: overdue[0]?.n ?? 0,
		events: events[0]?.n ?? 0,
		logs
	};
});
//#endregion
export { assignDepartmentMember_createServerFn_handler, checkinEvent_createServerFn_handler, deleteAnnouncement_createServerFn_handler, deleteContent_createServerFn_handler, deleteCourseItem_createServerFn_handler, deleteCourse_createServerFn_handler, deleteEvent_createServerFn_handler, deleteMember_createServerFn_handler, deleteTask_createServerFn_handler, getAnalytics_createServerFn_handler, getCourse_createServerFn_handler, getDashboard_createServerFn_handler, getDepartment_createServerFn_handler, getEvent_createServerFn_handler, getMe_createServerFn_handler, getMember_createServerFn_handler, globalSearch_createServerFn_handler, joinEvent_createServerFn_handler, listAnnouncements_createServerFn_handler, listAttendanceEvents_createServerFn_handler, listCalendar_createServerFn_handler, listContent_createServerFn_handler, listCourses_createServerFn_handler, listDepartments_createServerFn_handler, listEvents_createServerFn_handler, listMembers_createServerFn_handler, listNotifications_createServerFn_handler, listTasks_createServerFn_handler, manualCheckin_createServerFn_handler, markNotificationsRead_createServerFn_handler, patchMember_createServerFn_handler, removeDepartmentMember_createServerFn_handler, requestPasswordReset_createServerFn_handler, reviewContent_createServerFn_handler, saveAnnouncement_createServerFn_handler, saveContent_createServerFn_handler, saveCourseItem_createServerFn_handler, saveCourse_createServerFn_handler, saveEvent_createServerFn_handler, saveSignupIdentity_createServerFn_handler, saveTask_createServerFn_handler, setCheckinOpen_createServerFn_handler, setCoursePublic_createServerFn_handler, setEventPublic_createServerFn_handler, setTaskStatus_createServerFn_handler, updateMyProfile_createServerFn_handler };

//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BVqu4XSZ.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/_app",
			"/login",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-jKMOsQRV.js",
			"/assets/rolldown-runtime-hePW80VL.js",
			"/assets/react-CwJFpaho.js",
			"/assets/preload-helper-BV21WRLi.js",
			"/assets/link-C4lCxtKA.js",
			"/assets/jsx-runtime-BW84LJTq.js",
			"/assets/matchContext-CKhXGkS-.js",
			"/assets/utils-DlNdsw-o.js",
			"/assets/useStore-D5Glu-2o.js",
			"/assets/useRouter-Tlq4ymmd.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-jKMOsQRV.js"
		} }]
	},
	"/_app": {
		filePath: "/workspace/src/routes/_app.tsx",
		children: [
			"/_app/analytics",
			"/_app/attendance",
			"/_app/calendar",
			"/_app/courses",
			"/_app/departments",
			"/_app/events",
			"/_app/huong-dan",
			"/_app/media",
			"/_app/members",
			"/_app/notifications",
			"/_app/settings",
			"/_app/tasks",
			"/_app/",
			"/_app/checkin/$eventId"
		],
		preloads: [
			"/assets/_app-D3SWCBLc.js",
			"/assets/utils-DqKhNtuY.js",
			"/assets/client-DB0cfN8r.js",
			"/assets/use-current-user-C-lWGZyF.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DYQ8xUzN.js",
			"/assets/utils-DqKhNtuY.js",
			"/assets/client-DB0cfN8r.js",
			"/assets/use-current-user-C-lWGZyF.js",
			"/assets/field-C4m7dYfV.js",
			"/assets/button-IsITgDl-.js",
			"/assets/input-UKQFd-6C.js"
		]
	},
	"/_app/analytics": {
		filePath: "/workspace/src/routes/_app/analytics.tsx",
		children: void 0,
		preloads: [
			"/assets/analytics-Cr_GGogu.js",
			"/assets/constants-DcZH-qMB.js",
			"/assets/use-rpc-D4Bhib9b.js",
			"/assets/format-vmeYrjmo.js"
		]
	},
	"/_app/attendance": {
		filePath: "/workspace/src/routes/_app/attendance.tsx",
		children: void 0,
		preloads: [
			"/assets/attendance-DD2PxCYB.js",
			"/assets/use-rpc-D4Bhib9b.js",
			"/assets/format-vmeYrjmo.js",
			"/assets/toggle-BqcJTIRn.js"
		]
	},
	"/_app/calendar": {
		filePath: "/workspace/src/routes/_app/calendar.tsx",
		children: void 0,
		preloads: ["/assets/calendar-ZV_-JEny.js", "/assets/use-rpc-D4Bhib9b.js"]
	},
	"/_app/courses": {
		filePath: "/workspace/src/routes/_app/courses.tsx",
		children: ["/_app/courses/$id", "/_app/courses/"],
		preloads: ["/assets/courses-D-rE7HBE.js"]
	},
	"/_app/departments": {
		filePath: "/workspace/src/routes/_app/departments.tsx",
		children: ["/_app/departments/$id", "/_app/departments/"],
		preloads: ["/assets/departments-D-rE7HBE.js"]
	},
	"/_app/events": {
		filePath: "/workspace/src/routes/_app/events.tsx",
		children: ["/_app/events/$id", "/_app/events/"],
		preloads: ["/assets/events-D-rE7HBE.js"]
	},
	"/_app/huong-dan": {
		filePath: "/workspace/src/routes/_app/huong-dan.tsx",
		children: void 0,
		preloads: ["/assets/huong-dan-DoP8F9r9.js", "/assets/use-rpc-D4Bhib9b.js"]
	},
	"/_app/media": {
		filePath: "/workspace/src/routes/_app/media.tsx",
		children: void 0,
		preloads: [
			"/assets/media-5Gu0gtG-.js",
			"/assets/constants-DcZH-qMB.js",
			"/assets/use-rpc-D4Bhib9b.js",
			"/assets/format-vmeYrjmo.js",
			"/assets/field-C4m7dYfV.js",
			"/assets/button-IsITgDl-.js",
			"/assets/input-UKQFd-6C.js",
			"/assets/empty-state-Dv9UabBu.js"
		]
	},
	"/_app/members": {
		filePath: "/workspace/src/routes/_app/members.tsx",
		children: ["/_app/members/$id", "/_app/members/"],
		preloads: ["/assets/members-D-rE7HBE.js"]
	},
	"/_app/notifications": {
		filePath: "/workspace/src/routes/_app/notifications.tsx",
		children: void 0,
		preloads: [
			"/assets/notifications-DLRqcPb7.js",
			"/assets/constants-DcZH-qMB.js",
			"/assets/use-rpc-D4Bhib9b.js",
			"/assets/format-vmeYrjmo.js",
			"/assets/field-C4m7dYfV.js",
			"/assets/button-IsITgDl-.js",
			"/assets/input-UKQFd-6C.js"
		]
	},
	"/_app/settings": {
		filePath: "/workspace/src/routes/_app/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-oKRGuU53.js",
			"/assets/constants-DcZH-qMB.js",
			"/assets/use-rpc-D4Bhib9b.js",
			"/assets/field-C4m7dYfV.js",
			"/assets/button-IsITgDl-.js",
			"/assets/input-UKQFd-6C.js"
		]
	},
	"/_app/tasks": {
		filePath: "/workspace/src/routes/_app/tasks.tsx",
		children: void 0,
		preloads: [
			"/assets/tasks-KYEcQ5-P.js",
			"/assets/constants-DcZH-qMB.js",
			"/assets/use-rpc-D4Bhib9b.js",
			"/assets/format-vmeYrjmo.js",
			"/assets/field-C4m7dYfV.js",
			"/assets/button-IsITgDl-.js",
			"/assets/input-UKQFd-6C.js"
		]
	},
	"/_app/": {
		filePath: "/workspace/src/routes/_app/index.tsx",
		children: void 0,
		preloads: [
			"/assets/_app-bcKaKxU9.js",
			"/assets/use-rpc-D4Bhib9b.js",
			"/assets/format-vmeYrjmo.js",
			"/assets/button-IsITgDl-.js"
		]
	},
	"/_app/checkin/$eventId": {
		filePath: "/workspace/src/routes/_app/checkin.$eventId.tsx",
		children: void 0,
		preloads: ["/assets/checkin._eventId-CtGIWzKB.js"]
	},
	"/_app/courses/$id": {
		filePath: "/workspace/src/routes/_app/courses.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/courses._id-CBxFdvYo.js",
			"/assets/use-rpc-D4Bhib9b.js",
			"/assets/field-C4m7dYfV.js",
			"/assets/button-IsITgDl-.js",
			"/assets/input-UKQFd-6C.js"
		]
	},
	"/_app/departments/$id": {
		filePath: "/workspace/src/routes/_app/departments.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/departments._id-DdgIvYat.js",
			"/assets/constants-DcZH-qMB.js",
			"/assets/use-rpc-D4Bhib9b.js",
			"/assets/button-IsITgDl-.js",
			"/assets/input-UKQFd-6C.js"
		]
	},
	"/_app/events/$id": {
		filePath: "/workspace/src/routes/_app/events.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/events._id-BgoEWvcC.js",
			"/assets/constants-DcZH-qMB.js",
			"/assets/use-rpc-D4Bhib9b.js",
			"/assets/format-vmeYrjmo.js",
			"/assets/toggle-BqcJTIRn.js",
			"/assets/button-IsITgDl-.js"
		]
	},
	"/_app/members/$id": {
		filePath: "/workspace/src/routes/_app/members.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/members._id-qhS214mu.js",
			"/assets/constants-DcZH-qMB.js",
			"/assets/use-rpc-D4Bhib9b.js",
			"/assets/format-vmeYrjmo.js",
			"/assets/field-C4m7dYfV.js",
			"/assets/button-IsITgDl-.js",
			"/assets/input-UKQFd-6C.js"
		]
	},
	"/_app/courses/": {
		filePath: "/workspace/src/routes/_app/courses.index.tsx",
		children: void 0,
		preloads: [
			"/assets/courses.index-CvaX7FQo.js",
			"/assets/constants-DcZH-qMB.js",
			"/assets/use-rpc-D4Bhib9b.js",
			"/assets/field-C4m7dYfV.js",
			"/assets/button-IsITgDl-.js",
			"/assets/input-UKQFd-6C.js",
			"/assets/empty-state-Dv9UabBu.js"
		]
	},
	"/_app/departments/": {
		filePath: "/workspace/src/routes/_app/departments.index.tsx",
		children: void 0,
		preloads: [
			"/assets/departments.index-CidTqxKI.js",
			"/assets/chevron-right-GaFj7FDm.js",
			"/assets/use-rpc-D4Bhib9b.js"
		]
	},
	"/_app/events/": {
		filePath: "/workspace/src/routes/_app/events.index.tsx",
		children: void 0,
		preloads: [
			"/assets/events.index-C7qN1sHn.js",
			"/assets/constants-DcZH-qMB.js",
			"/assets/use-rpc-D4Bhib9b.js",
			"/assets/format-vmeYrjmo.js",
			"/assets/field-C4m7dYfV.js",
			"/assets/button-IsITgDl-.js",
			"/assets/input-UKQFd-6C.js",
			"/assets/empty-state-Dv9UabBu.js"
		]
	},
	"/_app/members/": {
		filePath: "/workspace/src/routes/_app/members.index.tsx",
		children: void 0,
		preloads: [
			"/assets/members.index-COLHFVXe.js",
			"/assets/chevron-right-GaFj7FDm.js",
			"/assets/constants-DcZH-qMB.js",
			"/assets/use-rpc-D4Bhib9b.js",
			"/assets/empty-state-Dv9UabBu.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };

import { C as require_jsx_runtime, y as Link } from "./_libs/@tanstack/react-router+[...].mjs";
import { b as errorMessage } from "./_ssr/utils-D7h6xKRb.mjs";
import { U as setTaskStatus, f as getDashboard } from "./_ssr/fns-BZr3NIHM.mjs";
import { n as useRpc, t as PageHeader } from "./_ssr/use-rpc-ubY9dVF8.mjs";
import { n as formatDateTime, r as greeting } from "./_ssr/format-FEWD-XX_.mjs";
import { t as Button } from "./_ssr/button-naZWmM3u.mjs";
import { n as toast } from "./_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_app-C2Q4ycKl.js
var import_jsx_runtime = require_jsx_runtime();
function Dashboard() {
	const { data, loading, err, reload } = useRpc(() => getDashboard());
	if (loading) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-muted",
		children: "Đang tải…"
	});
	if (err || !data) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-accent",
		children: err
	});
	const { me, events, myTasks, announcements, memberCount, overdue, inProgress, pendingContent } = data;
	async function confirm(id, status) {
		try {
			await setTaskStatus({ data: {
				id,
				status
			} });
			toast.success("Đã cập nhật việc.");
			reload();
		} catch (e) {
			toast.error(errorMessage(e));
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Tổng quan",
			title: `${greeting()}, ${me.name.split(" ").slice(-1)[0]}`,
			desc: "Hôm nay câu lạc bộ đang làm gì."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Thành viên",
					value: memberCount
				}),
				me.canViewStaff ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Việc đang làm",
					value: inProgress
				}) : null,
				me.canViewStaff ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Quá hạn",
					value: overdue
				}) : null,
				me.canViewMedia ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
					label: "Content chờ duyệt",
					value: pendingContent
				}) : null
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: "Sự kiện sắp tới"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 grid gap-3 md:grid-cols-2",
				children: [events.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: "Chưa có sự kiện công bố."
				}) : null, events.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/events/$id",
					params: { id: e.id },
					className: "card-paper block p-5 hover:border-ink/30",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl break-words",
						children: e.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							formatDateTime(e.start_at),
							" · ",
							e.location || "—"
						]
					})]
				}, e.id))]
			})]
		}),
		me.canViewStaff ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: "Việc của bạn"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 space-y-3",
				children: [myTasks.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-muted",
					children: "Không có việc đang mở."
				}) : null, myTasks.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-paper flex flex-wrap items-center justify-between gap-3 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium break-words",
						children: t.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							t.priority,
							" · ",
							t.status
						]
					})] }), t.status === "TODO" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => confirm(t.id, "IN_PROGRESS"),
						children: "Xác nhận đang làm"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "ink",
						onClick: () => confirm(t.id, "COMPLETED"),
						children: "Xác nhận hoàn thành"
					})]
				}, t.id))]
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: "Bảng tin"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 space-y-3",
				children: announcements.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "card-paper p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg break-words",
						children: a.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 whitespace-pre-wrap break-words text-muted",
						children: a.body
					})]
				}, a.id))
			})]
		})
	] });
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card-paper p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "kicker",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 font-display text-4xl tabular-nums",
			children: value
		})]
	});
}
//#endregion
export { Dashboard as component };
